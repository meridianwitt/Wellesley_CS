import java.util.*; 
import java.io.*; 

// things to change: May consider having a helper method that makes the constructor cleaner. 
public class AdjMatGraph<T> implements Graph<T>{ 
  private int n; //num vertices 
  private T[] vertice; 
  private boolean [][] arcs; 
  private final int DEFAULT_CAP = 5; 
  private int vertexIndex;  
  
  public AdjMatGraph() { 
    n= 0; 
    arcs = new boolean [DEFAULT_CAP][DEFAULT_CAP]; 
    vertice = (T[])(new Object[DEFAULT_CAP]);
    vertexIndex = -1; // the value does not exisit
  } 
  
  public AdjMatGraph(String fileName) { 
    this(); // this calls the first constructor 
    
    try{ 
      Scanner scan = new Scanner(new File( fileName));
      // reading the vertices 
      while(!scan.next().equals("#")){ // while # has not been found ALSO this is skipping over the next token 
        vertice[n] =  (T) scan.next(); // string variable and your changing it into a (T) tytpe 
        n++;
      }
      // reading the arcs 
      while(scan.hasNext()) { 
        int i = scan.nextInt(); 
        int j = scan.nextInt(); 
        arcs[i-1][j-1] = true; // -1 because it starts at one instead of zero/ set it to true because it is a boolean. 
      } 
    } catch(FileNotFoundException e){ 
      System.out.println("ERROR: Second Constructor- tgf file cannot be read"); 
    } 
  }
  // Instance Methods:  
  public String toString(){
    String s = "i ";
    for( int k = 0; k< n; k++){ 
      s+= vertice[k]+ "  " ; 
    } s+= "\n"; 
    for(int i=0; i<n; i++){ 
      s+= vertice[i]+ " " ; 
      for(int j=0; j<n; j++){
        s += (arcs[i][j] == true) ? " 1 ":" - ";
        //s += arcs[i][j]+ " " ;  
      }s+=  "\n"; 
    }
    
    return s;
  }
  
// /** Returns true if this graph is empty, false otherwise. */
  public boolean isEmpty(){ 
    return (n == 0);    
  } 
  
  /** Returns the number of vertices in this graph. */
  public int n(){ 
    return n; 
  } 
  
  /** Returns the number of arcs in this graph. */
  public int m(){
    int arc = 0;
    for(int j=0; j<n; j++){ //go through the matrices
      for(int i=0; i<n; i++){
        if(arcs[i][j] == true && arcs[j][i] == true){arc++;}
      }
    }
    return arc;
  }
  
  public boolean isVertexPresent(T vertex1){ 
    boolean vertex = false; 
    for(int i = 0; i< n; i++){
      if(vertice[i].equals(vertex1)){ 
        vertex = true; 
        return vertex; 
      } 
    }
    return vertex; 
  } 
  
   public int findIndex( T vertex){   
    for (int i= 0; i< n; i++){ 
      if(vertice[i].equals(vertex)){
        vertexIndex =i; 
      } 
    }
    return vertexIndex; 
  } 
   
   public void increaseSize(){ 
     T[] tempVertex = (T[])(new Object[DEFAULT_CAP*2]);
     boolean [][] tempArc = new boolean[DEFAULT_CAP*2][DEFAULT_CAP*2]; 
     for( int i=0; i<n; i++){
       for(int j = 0; j <n; j++){
         tempVertex [i]=  vertice[i]; 
         tempArc[i][j] = arcs[i][j]; 
       }
     }
     vertice = tempVertex; 
     arcs=tempArc;
   }
   
   /** Returns true iff a directed edge exists b/w given vertices */
   public boolean isArc (T vertex1, T vertex2){ 
     int v1 = findIndex(vertex1); 
     int v2 = findIndex(vertex2);
     return(arcs[v1][v2] == true); 
   }
   
   public boolean isEdge (T vertex1, T vertex2){ 
     int v1 = findIndex(vertex1); 
     int v2 = findIndex(vertex2);
     return(arcs[v1][v2] == true && arcs[v2][v1] == true); 
   }
   
   public boolean isUndirected(){ 
     boolean undirected = false; 
     for(int i = 0; i< arcs.length; i++){ 
       for(int j = 0; j< arcs.length;  j++){
         if(arcs[i][j] == true && arcs[j][i] == true){
           undirected = true; 
         }else{ 
           return undirected; 
         } 
       }
     }
      return undirected;
   }
   
   public void addVertex(T vertex){
     if(n==vertice.length)
     if(n== arcs.length){increaseSize();};
     vertice[n] = vertex;
     n++;
   }
       
   /** Removes a single vertex with the given value from this graph.
     * If the vertex does not exist, it does not change the graph. */
   public void removeVertex (T vertex){ 
     int v1 = findIndex(vertex); 
     if(v1 > 0){
       for( int i = v1; i < n; i++){ 
         vertice[i] = vertice[i+1]; 
       }
       for(int i = v1; i< n; i++){ //row removal
         for(int j = 0; j< n;j++){
           arcs[i][j]= arcs[i+1][j]; 
         }
       }
       for(int i = v1; i< n; i++){ //column removal
         for(int j = 0; j< n;  j++){
           arcs[i][j]= arcs[i][j+1]; 
         }
       }
       System.out.println("N gets: " + n); 
       n--; 
     } else {
       System.out.println("This vertex does not exist!");
     }
   }

 /** Inserts an arc between two vertices of this graph,
    * if the vertices exist. Else it does not change the graph. */
   public void addArc (T vertex1, T vertex2){
     int v1 =  findIndex(vertex1); 
     int v2 = findIndex(vertex2); 
     arcs[v1][v2]= true; 
   }  
   
   public void removeArc (T vertex1, T vertex2){
     int v1 =  findIndex(vertex1); 
     int v2 = findIndex(vertex2); 
     arcs[v1][v2]= false; 
   }  
   
     /** Inserts an edge between two vertices of this graph,
       * if the vertices exist. Else does not change the graph. */
   public void addEdge (T vertex1, T vertex2){ 
     int v1 =  findIndex(vertex1); 
     int v2 = findIndex(vertex2); 
     arcs[v1][v2]= true; 
     arcs[v2][v1]= true; 
   }
   
   public void removeEdge (T vertex1, T vertex2){ 
     int v1 =  findIndex(vertex1); 
     int v2 = findIndex(vertex2); 
     arcs[v1][v2]= false; 
     arcs[v2][v1]= false; 
   }
   
  
  
  /** Retrieve from a graph the vertices adjacent to vertex v.
   Assume that the vertex is in the graph */
   public LinkedList<T> getSuccessors(T vertex){ //a linked list of arrays, right?
     int v1 =  findIndex(vertex); 
     LinkedList<T> list = new LinkedList<T>(); 
     for( int i = 0; i < n; i++){ 
       if(arcs[v1][i]== true){ 
         list.add(vertice[i]); 
       } 
     } 
   
   return list; 
} 
   
/** Retrieve from a graph the vertices x preceding vertex v (x->v)
     and returns them onto a linked list */
 public LinkedList<T> getPredecessors(T vertex){ 
   int v1 =  findIndex(vertex); 
   LinkedList<T> list = new LinkedList<T>(); 
   for( int i = 0; i < n; i++){ 
     if(arcs[i][v1]== true){ 
       list.add(vertice[i]); 
     } 
   } 
   
   return list; 
} 
  /** Saves the current graph into a .tgf file.
   If it cannot save the file, a message is printed. */
  public void saveTGF(String tgf_file_name){
    try{PrintWriter p = new PrintWriter(new File(tgf_file_name));
   
   for(int i=0; i<n; i++){
     p.print(i+1 + " " + vertice[i] + "\n");
   }
     p.print("#");
     for(int j=0; j<n; j++){ //go through the matrices
       for(int i=0; i<n; i++){
        if(arcs[i][j] == true) p.print((i+1) + " " + (j+1));
       }
   //find boolean true for arc, return the nodes
     p.close();
     }}
    catch(FileNotFoundException ex){
     System.out.println("No title to write file to");
    }
  }
   
   public static void main(String [] args){ 
    AdjMatGraph<String> g1 = new AdjMatGraph<String>("g1.txt"); 
    System.out.println("Values in g1: \n" + g1);
//    System.out.println("Number of values: " + g1.n()); 
//    System.out.println("Number of arcs: " +  g1.m()); 
//    System.out.println("Testing isVertex gets true: " +  g1.isVertexPresent("4")); 
//    System.out.println("Testing isVertex gets true: " +  g1.findIndex("4")); 
//    
//    System.out.println("Testing isArc gets true: " +  g1.isArc("1","2"));
//    System.out.println("Testing isArc gets true: " +  g1.isArc("3","4"));
//    
//    
//    System.out.println("Testing isEdge gets true: " +  g1.isEdge("1","2"));
//    System.out.println("Testing isEdge gets false: " +  g1.isEdge("3","4"));
//    
//    System.out.println("Testing undirected gets false: " +  g1.isUndirected());// note: test a true statement 
//   
//    g1.increaseSize(); 
//    System.out.println("Testing increaseSize gets:\n " +  g1);
//    
//    g1.removeVertex("3"); 
//    System.out.println("Testing removeVertex gets:\n " +  g1);
//   
//    g1.addEdge("1", "4"); 
//    System.out.println(g1); 
//    
//    g1.removeEdge("1", "4"); 
//    System.out.println(g1);
//    
//    System.out.println("Testing getSuccessors[4]  " +  g1.getSuccessors("3"));
//    System.out.println("Testing getSuccessors[]  " +  g1.getSuccessors("4"));
//    System.out.println("Testing getPredecessors [1] " +  g1.getPredecessors("2"));
//    System.out.println("Testing getPredecessors[] " +  g1.getPredecessors("3"));
    //
    g1.addVertex("6");
    g1.addVertex("5");
   // g1.removeVertex("3");
    System.out.println(g1);
    g1.saveTGF("g1.tgf"); 
    
  } 
  

} 
