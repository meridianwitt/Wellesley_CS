/** 
 * FILE NAME: KuzcoPoisonGUI.java
 * WHEN: May 13, 2014
 * WHAT: GUI to hold together all of the tabbed panes and panels (the about panel and the parsing panel). 
 */

import javax.swing.*;
import java.io.*;

public class KuzcoPoisonGUI {
  
  /** 
 * main(): Holds the GUI together. 
 * Prompts a dialog box introducing the program, an open dialog box to choose a file to parse, and then leads 
 * to the main GUI.
 **/
  public static void main(String[] args) {

    JFrame frame = new JFrame ("Kuzco's Poison");
    frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
    
    int again =0;
    File file = null;
    
    JOptionPane.showMessageDialog(null,"Welcome to Kuzco's Poison! Please select a .txt file.");
    
    JFileChooser chooser = new JFileChooser();
    int status = chooser.showOpenDialog(null);
    
    if(status != JFileChooser.APPROVE_OPTION){
      JOptionPane.showMessageDialog(null,"Oops! You did not select a file. Please close the window.");
    } else {
      file = chooser.getSelectedFile();
      KuzcoPoisonPanel panel = new KuzcoPoisonPanel(file);
      KuzcoPoisonAboutPanel panel2 = new KuzcoPoisonAboutPanel();

      JTabbedPane tp = new JTabbedPane();
  
      tp.addTab("Ask Kronk", panel);
      tp.addTab("About", panel2);
      
      frame.getContentPane().add(tp);
      
      frame.pack();
      frame.setVisible(true);
    }

   }
}