/** 
 * FILE NAME: HashDoc.java
 * WHEN: May 13, 2014
 * WHAT: Creates an instance of HashDoc, in which the words of the given document are not only hashed, but also given 
 * values related to their number of occurances in the document and their frequencies in the document and the English
 * language (values stored in an array). 
 */

import java.util.*;
import java.io.*;

public class HashDoc{
  private HashWords wordFreqDoc;
  private StopWords stopList;
  private LinkedList<String> badWords;
  private File fileName;
  private Hashtable<String, double[]> docHashed;
  private int wordCount; 
  private final double MAX_OCCUR = .06; //our measurement of repititon when the word does not appear in the ANC list 
  
 /** 
 * Constructor: Creates an instance of HashDoc with the filename and count.
 * Creates an instance of HashWords, an empty HashDoc (populates HashDoc with constructHash()), an instance of StopWords 
 * and a empty list for highly repeated badWords.
 * Allows the user to either input the wordcount, or will count the number of words with getCount().
 * HashDoc also takes in the changed/added to instance of StopWords.
 **/
  
  public HashDoc(File file, int count, StopWords sw) {
      fileName = file;
      wordFreqDoc = new HashWords();
      wordFreqDoc.readInFile(); //populates the hashtable
      stopList = sw;
      badWords = new LinkedList<String>();
      docHashed = new Hashtable();
      if (count== 0) {
        wordCount = getCount();
      } else {
        wordCount = count;
      }
      
      docHashed = this.constructHash();
  }
 /** 
 * constructHash(): populates and returns the HashDoc hashtable. The meat and potatoes of our program!
 * The scanner reads the input file to be hashed and creates an empty array to store the text analysis values.
 * 
 * wordStatistics[0] is the frequency of occurances in the English language as noted by the ANC calculated in hashWords.
 * wordStatistics[1] represents the number of occurances in the input document.
 * wordStatistics[2] is the frequency in which the word occurs in the input document.
 * 
 * Ignoring the words in the StopWords class, it first searches to see if the word has already been hashed in HashDoc 
 * with the method containsKey(). If so, it removes it (only to put it back at the end).
 * Because wordStatistics[1] represents the number of occurances in the text, it is incremented whenever a word is found.
 * 
 * If the word has not been hashed before, then we search for the word in the HashWords hashtable with the getter 
 * getValue() and set the wordStatistics[1] as 1. 
 * 
 * If it is in Hashwords, we set wordStatistics[0] as getValue of the word.
 * If it is not HashWords, it's not a commonly used word, so we leave wordStatistics[0] in the English language as 0.
 * 
 * Then, wordStatistics[2] is set based on wordStatistics[1] and the wordcount. 
 * The addition of the word to the highly used list of badWords is decided by whether:
 * the word appears in the document with more frequency than in English language and occurs at least 6% of the time, 
 * and if the word is not already on the badwords list.
 * 
 **/

  private Hashtable constructHash() {
    try{ 
      Scanner scan = new Scanner(fileName);
      //getCount();
      while (scan.hasNext()) {
        double[] wordStatistics = {0.0,0.0,0.0}; 
        String word = scan.next();
        word = removePunc(word);
        if(!stopList.containWord(word)) { //only adds word if it's not on the stoplist list
          if(docHashed.containsKey(word)){
            wordStatistics = docHashed.remove(word); //stores everything before it removes from it
            wordStatistics[1] ++;  //increment the number of times we've seen the word
          } else { //
            if(wordFreqDoc.searchWord(word)) { 
              wordStatistics[0] = wordFreqDoc.getValue(word);
            } 
            wordStatistics[1] = 1; //the number of times its appeared so far (this is the first instance)
          }
          wordStatistics[2] = wordStatistics[1]/wordCount; //the percent of the paper that is this word
          //if word is used too often in paper (more than 6% of time) and it's not already on bad words list
          if (wordStatistics[0]<wordStatistics[2] && !badWords.contains(word) && wordStatistics[2] > MAX_OCCUR){
            badWords.add(word);
          }
          docHashed.put(word, wordStatistics);      
        }
      }
    } catch(FileNotFoundException ex){
      System.out.print("File Not Found!");
    }
    return docHashed;
  }
  
 /** 
 * getCount(): This private method scans the file and counts the number of words. 
 **/
  
  private int getCount() {
    int count = 0;
    try{
      Scanner scan = new Scanner(fileName);
      while(scan.hasNext()){
        scan.next();
        count++;
      }
    } catch (FileNotFoundException ex) {
      System.out.println("Not found");
    }
    return count;
  }
    
 /** 
 * removePunct(): This private methodus used to remove the punctuation of the input document. 
 **/  
  private String removePunc(String w) {
    String changed = w.toLowerCase().replaceAll("\\p{Punct}","");
    return changed;
  }

 /** 
 * getBadWords(): This getter method is used by askKronk. 
 **/  
  public LinkedList<String> getBadWords() {
    return badWords;
  }
  
 /** 
 * getFreqValue(): This getter method used in AskKronk in the toString() and getWordsReport() 
 * that shows the word and its frequency. 
 * If the word is not in the hash table, it will return -1.
 **/
  public double getFreqValue(String w) {
    if (docHashed.containsKey(w)) {
    double[] temp = docHashed.get(w); //saves the array value object
    return temp[1]; 
    } else {
      System.out.println(w + " is not in this document.");
      return -1;
    }
  }
  
  /** 
 * getWordCount(): This getter method used in AskKronk in the toString() and getWordsReport()
 * purposely casts the double as an int for aesthetic reasons. There will never be a fraction 
 * of a word, so no information is actually lost. 
 **/
  public int getWordCount() {
    return (int) wordCount; 
  }
  
 /** 
 * getStopWords(): This getter method is also used in the AskKronk toString to return the stopwords as a string.
 **/
  
  public String getStopWords() {
    return stopList.toString();
  }
  
  
/** 
 * toString(): Allows string representation of our HashDoc object. Prints the keys, the value array, the badwords, and
 * number of words. This is just for testing.
 **/
  public String toString(){
    int counter = 0;
    String s= "Your document is " + fileName+ ". \n";
    for(Enumeration<String> e = docHashed.keys(); e.hasMoreElements();){ //stepping through hash table
      String key = e.nextElement();
      counter++;
      s+= key + "[ ";
      double[] values = docHashed.get(key);
      for(int j=0; j<3; j++) { //stepping through wordStatistics[]
        s+= values[j] + " ";
      }
      s+= "] \n";
    }
    s+= "\n" + badWords; //calls linkedList's toString();
    System.out.println(counter);
    return s;
  }
  
/** 
 * main(): Used for testing. 
 **/
  
  public static void main(String[] args){
   StopWords testerStopWords = new StopWords();
   HashDoc test = new HashDoc(new File("test1.txt"),66, testerStopWords);
   System.out.println(test.toString());
   
   HashDoc test2 = new HashDoc(new File("real paper.txt"), 0, testerStopWords);
   System.out.println(test2);
   System.out.println("\n---- Testing getCount()----");
   System.out.println("Total word count in real paper (1163): " + test2.getCount());
   System.out.println("Total word count in test1.txt (66): " + test.getCount());
   System.out.println("\n---- Testing getBadWords()----");
   System.out.println("Bad words in real paper.txt (should be empty): " + test2.getBadWords());
   System.out.println("Bad words in test1.txt (word): " + test.getBadWords());
   System.out.println("\n---- Testing getFreqValue()----");
   System.out.println("'However' used in paper 2 times? " + test2.getFreqValue("however"));
   System.out.println("'Oops' used in paper -1 times? " + test2.getFreqValue("oops"));
   System.out.println("\n---- Testing getWordCount()----");
   System.out.println("real paper has 1163 word? " + test2.getWordCount());
   System.out.println("text1.txt has 66 words? " + test.getWordCount());
   System.out.println("\n---- Testing getStopWords()----");
   System.out.println("Stop words: " + test2.getStopWords());
   //System.out.println("\n Testing removePunc \n EXPECTED: There you are Its fun \n GOT:" + test.removePunc("There you are! It's fun!"));
  }
  
  }
  
    
