
/** 
 * FILE NAME: AskWendyPanel.java
 * WHEN: May 2, 2014
 * WHAT: Sets up the Panel that contains the Ask Wendy Driver.
 *
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;


public class KuzcoPoisonPanel extends JPanel {
  //instance vars
  private JPanel prompt, returned, buttonstuff;
  private JButton goButton;
  private JLabel filePrompt,stopWordPrompt, wordcountPrompt,fileName;//ranking, topFive; 
  private JLabel rankingReturned, badWordsReport;
  private JTextField stopWords, wordcount;
  private AskKronk kronk;
  private JFileChooser chooser;
  private File file;
  private Scanner scanner;
  
  
  // Constructor. Notice how it takes an instance of the game as input!
  public KuzcoPoisonPanel(File f) {//as of now, does not take in anything
    kronk= null;
    file = f;  
    filePrompt = new JLabel("The file you selected is: ");
    fileName = new JLabel(file.getName());   
    
    wordcountPrompt = new JLabel("<html>Enter the word count if known. Otherwise, write 0.</html>");
    wordcount = new JTextField();
    
    stopWordPrompt = new JLabel("<html> Please enter any words you " +
                                "<br>would like to exclude from the" + 
                                "<br> frequency count. Separate with commas only, NO SPACE.");
    stopWords = new JTextField();
    
    rankingReturned = new JLabel("nothing");
    badWordsReport = new JLabel("");
    goButton = new JButton("Go!");
    
    prompt = new JPanel();
    prompt.setLayout(new GridLayout(3,4));
    prompt.add(filePrompt);
    prompt.add(fileName);
    prompt.add(wordcountPrompt);
    prompt.add(wordcount);
    prompt.add(stopWordPrompt);
    prompt.add(stopWords);
    prompt.setVisible(true);
    prompt.setBackground(Color.CYAN);
    
    JPanel buttonstuff = new JPanel(); 
    buttonstuff.setLayout(new BorderLayout());
    goButton.addActionListener(new ButtonListener());
    buttonstuff.add(goButton, BorderLayout.CENTER);
    buttonstuff.setVisible(true);
    buttonstuff.setBackground(Color.CYAN);
    
    returned = new JPanel();
    returned.setLayout(new GridLayout(3,4));
    returned.add(rankingReturned);
    returned.add(badWordsReport);
    returned.setBackground(Color.CYAN);
    returned.setVisible(false);
    
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setPreferredSize(new Dimension(300, 300));
    add(prompt);
    add(buttonstuff);
    add(returned);
    
    //setBackground(Color.CYAN);
    
    //need actionlistener for textfields or just getText?
  }
  
  /**
   * ButtonListener is a private class for responding to button push events 
   */ 
  
  private class ButtonListener implements ActionListener {
    public void actionPerformed (ActionEvent event) {
       //kronk = new AskKronk(fileName.getText(), Integer.parseInt(wordcount.getText()));
      //kronk = new AskKronk(file, Integer.parseInt(wordcount.getText()));
       String userStopWords = stopWords.getText(); //can be empty
       String[] userWords = userStopWords.split(",");
       kronk = new AskKronk(file, Integer.parseInt(wordcount.getText()), userWords);
       String rating = kronk.rating();
       rankingReturned.setText("<html><center> " + rating + "</center></html>");
       returned.setVisible(true);
       int words = kronk.getNumBad();
       if (words == 0) {
      returned.setBackground(Color.GREEN);
    } else if (words<= 3) {
        returned.setBackground(Color.YELLOW);
       badWordsReport.setText(createReport());
    } else if (words>3) {
       returned.setBackground(Color.RED);
       badWordsReport.setText(createReport());
      } 
     
    } //end actionPerformed
    
    public String createReport() {
      String s = ("<html><center> The words you repeated too often are: ");
      LinkedList<String> report = kronk.getWordsReport(); 
      for (int i= 0; i<report.size(); i++){
        s+= "<br><center> " + report.get(i);
      }
      //s+= ("<br>The following words were excluded from the search: " + kronk.docHashed.getStopWords());
      return s;
    }
    
  } // end of buttonListener inner class
  }
 