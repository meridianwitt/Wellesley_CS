/** 
 * FILE NAME: StopWords.java
 * WHEN: May 13, 2014
 * WHAT: 
 * Creates a LinkedList collection of stopwords. 
 * Stopwords are words that the HashDoc will ignore.
 */

import java.util.*;
import java.io.*;

public class StopWords{
  //instance variables
  private LinkedList<String> collection;
  
 /** 
 * Constructor: This constructor is private because the user does not need to know what file we are reading from.
 * Creates an instance of StopWords with the filename.
 * It creates and populates a LinkedList from the file. 
 **/
  private StopWords(String file){
    try{
      Scanner scan = new Scanner(new File(file));
      int i=0;
      collection = new LinkedList<String>();
      while(scan.hasNext()){
        String line = scan.next();
        line.toLowerCase();
        collection.add(line);
        i++;
      } 
    }
    catch(FileNotFoundException ex){
      System.out.print("Stop words File Not Found!");
    }
  }
  //ADDED BY SARAH
  
  /** 
 * Second Constructor: Default to use the list we have
 **/
  public StopWords() {
    this("StopWords.txt");
  }
  
 
/** 
 * addWord(): Allows the user to addwords to the stopwords list collection.
 **/
  public void addWord(String word){
    collection.add(word.toLowerCase());
  }
  
 /** 
 * containWord(): "Getter" method used in HashDoc to see if a word is on the stopWords list.
 **/
  public boolean containWord(String word) {
    return collection.contains(word.toLowerCase());
  }
  
/** 
 *toString(): String representation of StopWords. 
 **/
  public String toString() {
    String s = "";
    for (int i=0; i<collection.size()-1; i++) {
      s+= collection.get(i) +", ";
    }
    s+= collection.get(collection.size()-1);
    return s;
  }
  
/** 
 *main(): Used to test StopWords. 
 **/
  public static void main(String[] args){
    StopWords wordy = new StopWords();
    System.out.println(wordy);
    System.out.println("----------Testing addWord()");
    wordy.addWord("I");
    System.out.println(wordy);
    System.out.println("----------Testing containWord()");
    System.out.println("Contains I? true: " + wordy.containWord("I"));
    System.out.println("Contains Heffilump? false: " + wordy.containWord("Heffilump"));
    System.out.println("----------Testing constructor w/parameters()");
    StopWords wordsSis = new StopWords("stopwordstext.txt");
    System.out.println("New StopWords document's contents: (and) " + wordsSis);
  }
}