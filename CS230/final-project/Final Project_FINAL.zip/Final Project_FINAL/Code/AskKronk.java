/** 
 * FILE NAME: AskKronk.java
 * WHEN: May 13, 2014
 * WHAT: Main class for Kuzco's Poison Program. Creates an instance of docHashed and other important variables
 * by taking in a file name and word count.  
 */

import java.util.*;
import java.io.*;

public class AskKronk{
  private HashDoc docHashed;
  private File fileName;
  private int numBadWords;
  private StopWords stopList;
  
  
/** 
 * Constructor: Creates an instance of askKronk with the filename and count.
 * The instance variable numBadWords is relevant to the implementation of the GUI and its color change.
 * Takes in a string array of desired stopwords from the user to be added to the stopList (new instance of stopwords).
 **/
  
  public AskKronk(File file, int count, String[] stopFromUser) {
    fileName = file;
    //docHashed = new HashDoc(fileName, count); 
    //numBadWords = docHashed.getBadWords().size();
    stopList = new StopWords();
    for (int i =0; i<stopFromUser.length; i++){
      //System.out.println("Adding this word from the linked list: " + stopFromUser.get(i));
      stopList.addWord(stopFromUser[i]);
    }
    docHashed = new HashDoc(fileName, count, stopList);
    numBadWords = docHashed.getBadWords().size();
    //System.out.println("Ask Kronk made");
  }
  
  
  /** 
 * rating(): This will return a String to the user that explains how repetitive the paper is.
 * The method counts the number of words in the badWords linkedlist from hashDoc. The list is available via the getter 
 * getBadWords() in HashDoc.
 * If the list is empty, you're creative. 
 * If it's more than 3, you're horribly redundant.
 * If it's less than 3, you're okay. These numbers can be changed.
 **/
  

  public String rating() {
    String results = "";
    //numBadWords = docHashed.getBadWords().size();
    //System.out.println(numBadWords);
    if (numBadWords == 0) {
      results = ("You're very creative! You didn't use any words too many times!");
    } else if (numBadWords<= 3) {
      results = ("You're somewhat redundant. You used " + numBadWords + ((numBadWords>1)? " words" : " word") + " too many times.");
    } else if (numBadWords>3) {
      results = ("You're horribly redundant! You used " + numBadWords + " words too many times."); 
    }
    return results;
  }
  
  
  /** 
 *getWordsReport(): 
 * "Getter method" interates through badWords-- retrieves the number times a word on the list was used from the HashDoc and 
 * stores both the bad word and its frequency value in the paper into a node in a linked list, which it then returns.
 * Used in the toString and the GUI. 
 **/
  
  public LinkedList<String> getWordsReport() {
    LinkedList<String> results = new LinkedList<String>();
    for (int i = 0; i<numBadWords; i++) {
      String word = (docHashed.getBadWords()).get(i);
      int freq = (int) docHashed.getFreqValue(word); //getter in HashDoc
      results.add(word + "(used "+ freq + " times in a paper of " + docHashed.getWordCount() + " words)");
    }
    return results;
    }
  
/** 
 *toString(): 
 * iterates through badWords-- retrieves the number times a word on the list was used from the HashDoc and 
 * prints both the bad word and its frequency value 
 * as well as a string representation of all the words in the StopWords collection
 **/
  
  public String toString() {

    String s= "\n";
    s+= ("According to your document, " + fileName+ ", " + rating());
    s+= ("\nHere are the words you used most often: ");
    LinkedList<String> wordsRep = getWordsReport(); 
    for (int i= 0; i<wordsRep.size(); i++){
      s+= "\n " + wordsRep.get(i);
    }
    s+= ("\nThe following words were excluded from the search: " + docHashed.getStopWords());
    return s;
  }
  
/** 
 getNumBad(): getter used in poison panel for changing the GUI color based on the number of badWords.
 **/
  
  public int getNumBad(){
   return numBadWords;
  }
  }
  