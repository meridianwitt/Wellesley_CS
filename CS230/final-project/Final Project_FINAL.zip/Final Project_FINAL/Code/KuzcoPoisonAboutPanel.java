/** 
 * FILE NAME: KuzcoPoisonAboutPanel.java
 * WHEN: May 13, 2014
 * WHAT: Tab to explain our program.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.applet.AudioClip;
import java.net.URL;

public class KuzcoPoisonAboutPanel extends JPanel {
  private JButton kusco;
  private JLabel descripTitle, descrip, question2Title, copyright;
  private AudioClip soundBite;
  
   /** 
 * Constructor: 
 * Creates the labels with information about our program and 
 * instantiates a button that can be played for an audio clip that inspired our program.
 **/
  public KuzcoPoisonAboutPanel() {

    URL url1 =null;
    try{
      url1 = new URL("file", "localhost", "Kusco's Poison.wav");
    } catch (Exception ex) {
      System.out.println("Can't find the file: " + ex);
      soundBite= null;}
    
    soundBite = JApplet.newAudioClip(url1);
    
    kusco= new JButton("", new ImageIcon("kronk.png"));
    kusco.addActionListener(new ButtonListener());
    
    descripTitle = new JLabel("<html> How is the rating calculated?");
    descripTitle.setFont(new Font("Helvetica", Font.BOLD, 16));
    descrip = new JLabel("<html>The brilliant (and modest) programmers found" 
                           + "<br> a list of the 5,000 most commonly used words"
                           +"<br> in the English language (www.wordfrequency.info)."
                           +"<br> If you use a word in your sample more than it's"
                           + "<br> used in English (calculated by percentages), then it's" 
                           + "<br> flagged as a Bad Word. If you used a word not found on the"
                           +"<br> frequency list, it can't be in more than 6% of the paper."
                           +"<br> If you have less than 3 Bad Words,"
                           + "<br> you're somewhat redundant. If you have more than 3, you're"
                           + "<br> horribly redundant. Otherwise you're very creative!");
    question2Title = new JLabel("<html> Why is it called Kuzco's Poison?");
    question2Title.setFont(new Font("Helvetica", Font.BOLD, 16));
    copyright = new JLabel("<html>This program was made by " 
                             + "Meridian Witt and Sarah Bailin. "
                             + "<br>References to The Emperor's New Groove "
                             + "were made without <br> the consent of Walt Disney Pictures,"
                          + " but the programmers <br> are confident they would approve.");
    
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    add(descripTitle);                    
    add(descrip);
    add(Box.createRigidArea(new Dimension (0,15)));
    add(question2Title);
    add(kusco);
    add(Box.createRigidArea(new Dimension (0,30)));
    add(copyright);
    
    setBackground(Color.CYAN);
  }
  
  private class ButtonListener implements ActionListener {
 /** 
 *actionPerformed(): makes the GUI play the clip when clicked.
 **/
    public void actionPerformed (ActionEvent event) {
      soundBite.play();
    }//end actionPerformed

}
}