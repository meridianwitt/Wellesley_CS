/** 
 * FILE NAME: AskKronkDriver.java
 * WHEN: May 13, 2014
 * WHAT: Driver class for Kuzco's Poison Program. 
 */

import java.util.*;
import java.io.*;

public class AskKronkDriver{
  
   public static void main(String[] args){
   String[] testerList = new String[1];
   testerList[0] = "hmm"; //chosen at random b/c known to not be in any document
   AskKronk test = new AskKronk(new File("test1.txt"), 66, testerList);
   System.out.println(test.rating());
   System.out.println(test.toString());
   
   System.out.println("\n----Adding word, 'word' to StopWords");
   testerList[0] = "word";
   AskKronk test1 = new AskKronk(new File("test1.txt"), 66, testerList);
   System.out.println(test1.toString());
   
   AskKronk test2 = new AskKronk(new File("test2.txt"), 0, testerList);
   System.out.println("\nCreated new AskKronk object using file w/words only" +
                      " found on Word Frequency doc. Includes some numbers.");
   System.out.println("Rating should be somewhat redundant w/ 2 words used too many times: " + test2.rating());
   System.out.println("\n----testing getWordsReport()---");
   LinkedList<String> report = new LinkedList<String>();
   report = test2.getWordsReport();
   System.out.println(report);
   System.out.println(test2);
   
   AskKronk test3 = new AskKronk(new File("real paper.txt"), 0, testerList);
   System.out.println("\nCreating new AskKronk object using a real academic paper." +
                      "Contains some numbers.");
   System.out.println("Expected to be very creative b/c if word is on badWords list, it had to be "
                        + "used 40+ times: " + test3);
  }
}