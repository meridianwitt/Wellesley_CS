/** 
 * FILE NAME: HashWords.java
 * WHEN: May 13, 2014
 * WHAT: 
 * Uses a list of the top 5000 words and the number of occurances in the English language 
 * compiled by Corpus of Contemporary American English. 
 * Stores each word as a key and the frequency it occured.
 */

import java.util.*;
import java.io.*;


public class HashWords {
  //instance variable

  private Hashtable<String, Double> languageWordTable; 
  private String fileName;
  private final double TOTAL_OCCUR = 329794508.0; //total number of words and occurances counted by the CCAE
  
 /** 
 * Constructor: This constructor is private because the user does not need to know what file we are reading from.
 * Creates an instance of HashWords with the filename.
 * It creates a hashtable and uses readInFile() to populate it.
 **/
  private HashWords(String file) {
    fileName = file;
    languageWordTable = new Hashtable(); 
    //totalFreq= 0;
    readInFile();
  }
  
/** 
 * Second Constructor: Default to use the list we have
 **/
  public HashWords() {
    this("Word Frequency.txt");
  }
  
/** 
 * readInFile(): populates the HashWords hashtable by reading in either the default or given file. 
 * Puts in each word as a key.
 * Calculates the frequency using the number of occurances given in the list and the total words CCAE counted.
 **/
  public void readInFile(){
    try{
    Scanner scan = new Scanner(new File(fileName));  
    int i=0;
    while(scan.hasNext()){
      String token = scan.next();
      //System.out.println(token);
      Double num = scan.nextDouble();
      //System.out.println("Token: " + token + "Number: " + num);
      languageWordTable.put(token, num/TOTAL_OCCUR); 
      i++;
    }
    scan.close();
    //System.out.println("There are " + i + " words in HashWords");
    } catch (FileNotFoundException ex) {
      System.out.println("Oops! File not found!");
    }
  }
  
/** 
 * searchWord(): "Getter" method used in hashDoc to see if the word is in the HashWords table. 
 **/
  public boolean searchWord(String search){
    return (languageWordTable.containsKey(search));
  }
  
/** 
 *getValue(): "Getter" method used in hashDoc to get the frequency of occurance in English from the HashWords table. 
 **/
  public Double getValue(String word) {
    return this.languageWordTable.get(word);
  }
 
 /** 
 *getTotalFreq(): "Getter" method for the total number of words counted by the CCAE. 
 **/
  public Double getTotalFreq() {
    //should return instance variable of all of the frequencies in the file added
    return TOTAL_OCCUR;
  }
  
 /** 
 *toString(): String representation of HashWords. 
 **/
  public String toString() {
    String s= "";
     for(Enumeration<String> e = languageWordTable.keys(); e.hasMoreElements();){ //stepping through hash table
      String key = e.nextElement();
//    Enumeration<String> e = languageWordTable.keys();
//    for(int i=0; i<6; i++){ //stepping through first 6 values of hash table
      s+= key + "[ ";
      s+= languageWordTable.get(key);
      s+= "] \n";
    }
    return s;
  }
  
 /** 
 *main(): Used to test hashwords.  
 **/
  public static void main(String[] args) throws FileNotFoundException{
    
    HashWords hashed = new HashWords();
    System.out.println("The value of the is (.0668): " + hashed.getValue("the"));
    System.out.println(hashed.getTotalFreq());
    System.out.println(hashed.toString());
    System.out.println("The is in the hashtable (true): " + hashed.searchWord("the"));
}
}