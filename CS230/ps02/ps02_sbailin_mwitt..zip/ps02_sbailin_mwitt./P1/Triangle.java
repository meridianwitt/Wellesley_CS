import java.util.*;

/* **
 * Purpose: Calculates the area of two triangles using Heron's Formula 
 *    and then compares the two areas to find the largest. 
 * Created By: Sarah Bailin and Meridian Witt
 * Date: February 7, 2014
 */

public class Triangle {
  
  final static double MAX = 0.01;
  private double halfPerim;  //half perimeter, or s in formula
  private double area;
  
  /* **
   * Constructor: Takes as input three doubles representing the three 
   * sides of a triangle and calculates the
   * perimeter and area using Heron's Forumla.
   */ 
  public Triangle (double a, double b, double c) {
    halfPerim = (a + b + c)/2.0;
    double side1 = halfPerim - a;
    double side2 = halfPerim - b;
    double side3 = halfPerim - c;
    area = Math.sqrt(halfPerim * side1 * side2 * side3);
  }
  
  /* **
   * Calculates the difference between the areas of two different
   * objects of this class. If this difference is less than the MAX,
   * then the triangles are approximately equal and so it returns true.
   */
  public boolean equals(Triangle different) {
    return (Math.abs(this.area - different.area)<= MAX);
  }
  
  /* **
   * Returns a string value of the area, which is currently 
   * a double.
   */
  public String toString(){
    return Double.toString(area);
  }
  
 /* **
  * Prompts user to enter values for the triangles and prints out 
  * their areas and whether they are equal.
  */
  public static void main (String[] args) {
    Scanner sam = new Scanner(System.in);
    
    System.out.println("This program will compare the area of"  
                         + " two triangles and determine if they are equal.");
    System.out.println("\n Please enter the three sides of the first triangle"
                         + " separated by a space.");
    Triangle tri1 = new Triangle(sam.nextDouble(), sam.nextDouble(), sam.nextDouble());
    
    System.out.println("\n Please enter the three sides of the second triangle"
                         + " also separated by a space.");
    Triangle tri2 = new Triangle(sam.nextDouble(), sam.nextDouble(), sam.nextDouble());
    
    System.out.println("\n The area of the first triangle is " + tri1.area);
    System.out.println(" The area of the second triangle is " + tri2.area);
    
    String same = "\n The two triangles have essentially the same area because their"
      + "\n difference is less than " + MAX;
    String diff = "\n The two triangles do not have the same area.";
    
    System.out.println((tri1.equals(tri2)) ? same : diff );
  }
  
}