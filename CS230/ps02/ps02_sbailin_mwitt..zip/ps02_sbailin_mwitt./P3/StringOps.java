/*
 *Meridian Witt and Sarah Bailin
 * Feb 9, 2014
 */

/*
 *Purpose: This class manipulates strings with 2 static methods. 
 * removeChar takes in a string and a character, and returns a new string without the input character.
 * testAnagrams takes in two words and tests if they are anagrams. 
 */

public class StringOps{
  
  /*
   *removeChar takes in a string and a character, and returns a new string without the input character. 
   * @charLoc gives the index of the incidence of char ch. 
   * @answer is the string returned. It is concatenation of the substrings before and after
   * char ch.
   */
  
  public static String removeChar(String s, char ch){
    s = s.toLowerCase();
    ch = Character.toLowerCase(ch);
    String answer = "";
    int charLoc = s.indexOf(ch);
    if(charLoc == -1){
      answer = s; //means ch is not in the string
    } else {
      answer = s.substring(0, charLoc) + s.substring(charLoc+1, s.length());
    }
    return answer;
  }
  
  /*
   *This is a helper method for testAnagrams. It generates a char array from the String word1. 
   */
  public static char [] toArray(String s) {
    char [] sArray = new char[s.length()];
    for(int i=0; i < s.length(); i++){
      sArray[i] = s.charAt(i); 
    }
    return sArray;
  }
  
  /*
   *testAnagrams compares two strings to see if they are anagrams. 
   * It initially checks to see if the words are the same,
   * and therefore are not anagrams.
   * 
   * Then, it rolls through a character array of the String word1 removing any common characters 
   * between word1 and word2. 
   * 
   * If it is an anagram, there will be nothing left. An empty string indicates that the words 
   * are anagrams. 
   */
  
  public static void testAnagrams(String word1, String word2){
    if(word1.equals(word2)){
      System.out.println( word1 + " is the same word as " + word2 + ".");
    } else {
        String mutatedString = word2;
        char [] wrd1char = toArray(word1);
        for(int i = 0; i < word1.length(); i++){
          mutatedString = removeChar(mutatedString, wrd1char[i]);
        }
        System.out.println((mutatedString.equals("")) ? word1 + " and " + word2 + " are anagrams!" : 
                             word1 + " and " + word2 + " are not anagrams.");
      }
  }
  
  /*
   *The main method tests the methods of StringOps. 
   */
  
  public static void main(String [] args){
    System.out.println(removeChar("",'a') + " is the result when removing 'a' " + "from " + " .");
    System.out.println(removeChar("java", 'a') + " is the result when removing 'a' " + "from " + "java."); 
    System.out.println(removeChar("happy", 'a') + " is the result when removing 'a' " + "from " + "happy.");
    System.out.println(removeChar("elephant", 'r') + " is the result when removing 'r' " + "from " + "elephant.");
    testAnagrams("melon", "lemon");
    testAnagrams("hello", "hello");
    testAnagrams("pink", "link");
    testAnagrams("", "j");
    testAnagrams(" apple", "p");
    testAnagrams(" apple", "apple");
  }
}