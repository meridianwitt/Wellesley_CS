/** Simulates a Dice Poker game played between the computer and user. 
  * This class definition contains a main() method that assumes 
  * that the user enters a name and an integer in the command line, for example: 
  * java PlayDice Wendy 7
  * @author   Takis Metaxas 
  * @version     %I%, %G%
  * 
  * Modified By: Sarah Bailin and Meridian Witt
  * Date Modified: February 9, 2014
  * 
  */


public class DiceGame {
  
  /** Creates a game object that contains the variables associated with a game.
    */
  
  String name; // Dave is the default
  int numRounds; // 5 rounds by default
  int pwin; //round wins of the player
  int cwin; //round wins of the computer
  
  public DiceGame() {
    pwin = 0;
    cwin = 0;
    
  }
  
  
  
  /** Counts how many distinct values appear in the input array
    * and stores each count onto the diceResults array.
    * PRE-CONDITION: diceResults[] should have enough length 
    * to accomodate the values found in the input array.
    *
    * @param input   the input array
    * @param diceResults  holds the multiplicity of values found in input.
    *       Note that this is actually the output parameter 
    */
  private void accumulateValues(int[] input, int[] diceResults) {
    for(int i=0;i<5; i++){
      int currentValue = input[i];
      diceResults[currentValue]++;//diceResults[0] will never hold anything
    }
  }
  
  /** Given an input array storing five dice values, 
    * determines the rank of the set of values 
    * @param input  the array with the five dice values
    * @return    the rank: an integer between 0 and 6
    */
  private int getRank (int[] input) { 
    int rank = 0;
    int pairs = 0;
    int threes = 0;
    for(int i=1;i<7; i++){
      rank = input[i];
      switch (rank) {
        case 2:
          pairs++;
          break;
        case 3:
          threes++;
          break;
        case 4:
          rank = 5;
          break;
        case 5:
          rank = 6;
          break;
        default:
          rank = 0;
          break;
      }
    }
    if (pairs == 1) {
      rank = 1;
    } else if (pairs == 2 && threes == 1) {
      rank = 4;
    } else if (pairs == 2) {
      rank = 2;
    } else if (threes == 1) {
      rank = 3;
    }
    return rank;
  }
  
  /* Helper method that determines the string description of 
   * the hand based on the integer rank  
   */ 
  private String verbalRanking(int rank){
    String s = " ";
    switch (rank) {
      case 0: 
        s = "Nothing";
        break;
      case 1:
        s = "One pair";
        break;
      case 2:
        s = "Two pair";
        break;
      case 3:
        s = "Three of a kind";
        break;
      case 4:
        s = "Full House";
        break;
      case 5:
        s = "Four of a kind";
        break;
      case 6:
        s = "Five of a kind";
        break;
    }
    return s;
  }
  
  
  /** Plays one round of the game: First the computer's turn, 
    * then the player's turn
    * @param name the player's name
    * @return   0 if computer wins the round, 1 if player wins, 2 if a tie
    */
  private int playOneRound(String name) {
    DicePlayer dicePlayer1 = new DicePlayer();
    //Compute and print out Computer's hand
    int [] compVals = dicePlayer1.getValues(); 
    int [] compResults = new int[7];
    accumulateValues(compVals, compResults);
    int compRank = getRank(compResults);
    System.out.println("HAL:" + convertArray(compVals) + ": " + verbalRanking(compRank));
    //Compute and print out Player's hand  
    int [] playerVals = dicePlayer1.getValues(); 
    int [] playerResults = new int[7];
    accumulateValues(playerVals, playerResults);
    int playerRank = getRank(playerResults);
    System.out.println(name + ": " + convertArray(playerVals) + ": " + verbalRanking(playerRank));
    
    if(compRank > playerRank){
      return 0;
    } else if (playerRank > compRank){
      return 1;
    } else {
      return 2;
    }
  }
  
  /** Helper method that converts the contents 
    * of an array into a string. 
    */
  public String convertArray(int[] numbers)  {
    String s ="";
    for(int i=0; i<numbers.length; i++)
      s += " " + Integer.toString(numbers[i]);
    return  s;
  }
  

  /**  Simulates the playing of numRounds of the Dice Poker game between 
    * HAL and player name, and prints the winner at the end
    * @param name   the player's name
    * @param numRounds  the number of rounds to play
    */
  public void playDiceGame (String name, int numRounds) {
    
    System.out.println("Good evening, " + name + ". Everything's running smoothly. And you?" + ".");
    System.out.println("I'm completely operational and all my circuits are functioning perfectly.");
    System.out.println("Would you like to play a game of Dice Poker? I play very well.");
    
    int currentRound = 1;
    do 
    {
      System.out.println("\n***  ROUND " + currentRound);
      int winner = playOneRound(name);
      switch (winner) {
        case 0:
          cwin++;
          break;
        case 1:
          pwin++;
          break;
        case 2:
          break;
      }
      currentRound++;
    } 
    while (currentRound <= numRounds);
    
    // After all rounds played, determine the final winner of the game and print the results
    if (pwin>cwin) System.out.print("\nThe game was won by "+ name + " with a score of " + pwin + " to " + cwin);
    else if (cwin>pwin) System.out.print("\nThe game was won by the HAL with a score of " + cwin + " to " + pwin);
    else System.out.print("\nThe game was tied with a score of " + cwin + " to " + pwin);
    
    System.out.println(" in " + numRounds + " rounds.");
    System.out.println("Thank you for a very enjoyable game!");
    
  }
  
  
  /** Start the homework by reading this method. 
    */
  public static void main (String args[]) {
    
    // Create an instance of a new game and play the rounds
    DiceGame game = new DiceGame();
    String name = (args.length >  0)? args[0] : "Dave";
    
    // 5 rounds by default
    int numRounds = (args.length >  1)? Integer.parseInt(args[1]) : 5; 
    game.playDiceGame(name, numRounds);
    
  }
  
}
