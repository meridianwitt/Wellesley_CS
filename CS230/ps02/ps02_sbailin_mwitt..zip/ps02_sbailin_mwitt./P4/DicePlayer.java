/** CODE TEMPLATE
* Creates the "hand" of a player by creating sn object of 5 random dice
* @author   Takis Metaxas 
* @version     %I%, %G%
* 
* Modified By: Sarah Bailin and Meridian Witt
* Date Modified: February 9, 2014
* 
*/


public class DicePlayer {

final private int hand = 5;
private Die[] FiveDice = new Die[hand];
 
    /** Constructor: Creates a player's hand by creating and rolling dice. 
     */   
 public DicePlayer() {
   for(int i=0; i<hand; i++){
    FiveDice[i] = new Die();
   }
 }
 
    /** Prints the contents of the hand that a player holds. 
    */
 public String toString()  {
   String s ="";
   int [] numbers = getValues();
   for(int i=0; i<hand; i++)
     s += " " + Integer.toString(numbers[i]);
   return  s;
 }

    /** Returns an array the contents of the hand that a player holds. 
     * @return integer array of @param hand values corresponding to dice
    */
    public int[] getValues() {
      int [] values = new int[hand];
      for(int i=0;i<hand;i++){
       values[i] = FiveDice[i].roll();
      }
      return values;
    }


  /** Testing method. 
  */
  public static void main (String args[]) {

 DicePlayer hal = new DicePlayer();
 System.out.println("Hal rolled " + hal);
 DicePlayer dave = new DicePlayer();
 System.out.println("Dave rolled " + dave);
 
  }
}
