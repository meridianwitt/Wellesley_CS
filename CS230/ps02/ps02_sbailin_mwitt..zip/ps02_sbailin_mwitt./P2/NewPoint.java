/*
 *Meridian Witt and Sarah Bailin
 * Feb 9, 2014
 */

/**
 * Purpose: Creates a point class.
 * */
  
public class NewPoint {
  private double x;
  private double y;
  
  public NewPoint(double valueX, double valueY) {
    x = valueX;
    y = valueY;
  }
  
  public double getX() {
    return x;
  }
  
  public double getY() {
    return y;
  }
  
  public String toString() {
    String s = " ";
    s += Double.toString(x) + " " + Double.toString(y);
    return s;
  }
}