import java.lang.Object;
import java.util.Scanner;

/**
 * Purpose: Calculate the appropriate distances and report which of 
 * the points P2 and P3 are closer to P1. If the distance is less than 0.01, 
 * the points are approximately equidistant. 
 * */
  

public class PointDistance{
  
  private double distance;
  private final double MAX =0.01;
  
  /*
   * Constructor: Calculates the distance between the x and y points of 
   * P1 and P2.
   * */
  
  public PointDistance(NewPoint p1, NewPoint p2){
    double valueX = (p2.getX() - p1.getX()) * (p2.getX() - p1.getX());
    double valueY = (p2.getY() - p1.getY()) * (p2.getY() - p1.getY());
    distance = Math.sqrt(valueX + valueY);
  }
  
  /*
   *Compares the distances of PointDistance objects. 
   * */
  
  public boolean equals(PointDistance another){
   return ((Math.abs(this.distance - another.distance))<= MAX);
  }
  
  /*
   *Converts the double value distance into a String. 
   */
  
  public String toString(){
   return Double.toString(distance);
  }
  
  /*
   *The main method creates PointDistance objects from user input and 
   * compares the distances of P2 and P3 from P1. 
   */
  
  public static void main(String [] args){
    System.out.println("Enter the two coordinates of a point (separated by a space):");
    Scanner sally = new Scanner(System.in);
    NewPoint p1 = new NewPoint(sally.nextDouble(), sally.nextDouble());
    System.out.println("Enter the two coordinates of a point (separated by a space)");
    NewPoint p2 = new NewPoint(sally.nextDouble(), sally.nextDouble());
    System.out.println("Enter the two coordinates of a point (separated by a space)");
    NewPoint p3 = new NewPoint(sally.nextDouble(), sally.nextDouble());
    PointDistance ptDistance1 = new PointDistance(p1,p2);
    PointDistance ptDistance2 = new PointDistance(p1,p3);
    System.out.println("Distance between P1 and P2: " + ptDistance1);
    System.out.println("Distance between P1 and P3: " + ptDistance2);
    System.out.println("Are P2 and P3 practically equidistant from P1? " + 
                       ptDistance1.equals(ptDistance2));
  }
}
