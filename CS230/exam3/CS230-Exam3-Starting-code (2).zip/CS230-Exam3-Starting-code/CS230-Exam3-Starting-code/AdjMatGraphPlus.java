/********************************************************************
  * AdjMatGraphPlus.java  Sample Solutions of Exam3 
  * Implementation of the GraphPlus.java interface using adjacency matrix
  * of booleans. 
  * KNOWN FEATURES/BUGS: 
  * It handles unweighted graphs only, but it can be extended.
  * 
  * Bugs:
  * Topological Sort, BFS, and DFS do not work.
  * 
  * I attempted to create topological sort with the second algorithm 
  * given in the course slides. 
  * 
  * I also attempted to implement BFS and DFS as I would preorder and 
  * levelorder. I also attempted to implement as impelemented in the 
  * textbook, but instead of queues I tried to use LinkedList.
  ********************************************************************/
import javafoundations.*;
import java.util.*;
import java.io.*;

public class AdjMatGraphPlus<T> implements GraphPlus<T>
{
  private final int NOT_FOUND = -1;
  private final int DEFAULT_CAPACITY = 1; // Small so that we can test expand
  
  private int n;   // number of vertices in the graph
  private boolean[][] arcs;   // adjacency matrix of arcs
  private T[] vertices;   // values of vertices
  private int numClone = 0;
  
  /******************************************************************
    Constructor. Creates an empty graph.
    ******************************************************************/
  public AdjMatGraphPlus()
  {
    n = 0;
    this.arcs = new boolean[DEFAULT_CAPACITY][DEFAULT_CAPACITY];
    this.vertices = (T[])(new Object[DEFAULT_CAPACITY]);
  }
  
  
  /******************************************************************
    * Second constructor:
    * Creates a new graph using the data found in a .tgf file.
    If the file does not exist, a message is printed. 
    *****************************************************************/
  public AdjMatGraphPlus(String tgf_file_name) {
    //reset current graph
    vertices = (T[]) (new Object[DEFAULT_CAPACITY]); 
    arcs = new boolean[DEFAULT_CAPACITY][DEFAULT_CAPACITY];
    n = 0;
    
    try{
      
      Scanner fileReader = new Scanner(new File(tgf_file_name));
      while (!fileReader.next().equals("#")){
        T line = (T) fileReader.next();
        addVertex(line);
      }
      
      while (fileReader.hasNext()){
        int arcVertex1 = fileReader.nextInt();
        int arcVertex2 = fileReader.nextInt();
        //System.out.println ("Arc Vertex 1: " + arcVertex1);
        //System.out.println ("Arc Vertex 2: " + arcVertex2);
        addArc(vertices[arcVertex1 -1], vertices[arcVertex2 -1]);
      }
      
    } catch (IOException ex) {
      System.out.println(" ***(T)ERROR*** The file was not found: " + ex);
    }
  }
  
  /******************************************************************
    Returns true if the graph is empty and false otherwise. 
    ******************************************************************/
  public boolean isEmpty()
  {
    return (n == 0);
  }
  
  /******************************************************************
    Returns the number of vertices in the graph.
    ******************************************************************/
  public int n()
  { return n; }
  
  /******************************************************************
    Returns the number of arcs in the graph by counting them.
    ******************************************************************/
  public int m()
  {
    int total = 0;
    
    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++)
      if (arcs[i][j]) total++; 
    return total; 
  }
  
  /******************************************************************
    Returns true iff a directed edge exists from v1 to v2.
    ******************************************************************/
  public boolean isArc (T vertex1, T vertex2){
    return isArc(getIndex(vertex1),getIndex(vertex2));
  }       
  
  
  /******************************************************************
    Helper. Returns true iff an arc exists between two given indices 
    ******************************************************************/
  private boolean isArc (int index1, int index2)
  {
    if (indexIsValid(index1) && indexIsValid(index2))
      return arcs[index1][index2] == true;
    else return false;
  }
  
  
  /******************************************************************
    Returns true iff an edge exists between two given vertices
    which means that two corresponding arcs exist in the graph
    ******************************************************************/
  public boolean isEdge (T vertex1, T vertex2){
    return (isArc(vertex1, vertex2) && isArc(vertex2, vertex1)); }
  
  
  /******************************************************************
    Returns true IFF the graph is undirected, that is, for every 
    pair of nodes i,j for which there is an arc, the opposite arc
    is also present in the graph.  
    ******************************************************************/
  public boolean isUndirected(){
    for (int i = 0; i < n(); i++)
      for (int j = 0; j < n(); j++)
      if (isArc(i,j))
      if (!isArc(j,i)) 
      return false;
    return true;
  };
  
  
  /******************************************************************
    Adds a vertex to the graph, expanding the capacity of the graph
    if necessary.  If the vertex already exists, it does not add it.
    ******************************************************************/
  public void addVertex (T vertex)
  {  if (getIndex(vertex) == NOT_FOUND) {
    if (n == vertices.length)
      expandCapacity();
    
    vertices[n] = vertex;
    for (int i = 0; i <= n; i++)
    {
      arcs[n][i] = false;
      arcs[i][n] = false;
    }      
    n++;
  }
  }
  
  /******************************************************************
    Helper. Creates new arrays to store the contents of the graph 
    withtwice the capacity.
    ******************************************************************/
  private void expandCapacity()
  {
    T[] largerVertices = (T[])(new Object[vertices.length*2]);
    boolean[][] largerAdjMatrix = 
      new boolean[vertices.length*2][vertices.length*2];
    
    for (int i = 0; i < n; i++)
    {
      for (int j = 0; j < n; j++)
      {
        largerAdjMatrix[i][j] = arcs[i][j];
      }
      largerVertices[i] = vertices[i];
    }
    
    vertices = largerVertices;
    arcs = largerAdjMatrix;
  }
  
  
  /******************************************************************
    Removes a single vertex with the given value from the graph.  
    Uses equals() for testing equality
    ******************************************************************/
  public void removeVertex (T vertex)
  {
    for (int i = 0; i < n; i++)
      if (vertex.equals(vertices[i]))
      removeVertex(i);
  }
  
  /******************************************************************
    Helper. Removes a vertex at the given index from the graph.   
    Note that this may affect the index values of other vertices.
    ******************************************************************/
  private void removeVertex (int index)
  {
    if (indexIsValid(index))
    {
      n--;
      
      for (int i = index; i < n; i++)
        vertices[i] = vertices[i+1];
      
      for (int i = index; i < n; i++)
        for (int j = 0; j <= n; j++)
        arcs[i][j] = arcs[i+1][j];
      
      for (int i = index; i < n; i++)
        for (int j = 0; j < n; j++)
        arcs[j][i] = arcs[j][i+1];
    }
  }
  
  /******************************************************************
    Inserts an edge between two vertices of the graph.
    If one or both vertices do not exist, ignores the addition.
    ******************************************************************/
  public void addEdge (T vertex1, T vertex2)
  {
    // getIndex will return NOT_FOUND if a vertex does not exist,
    // and the addArc calls will not insert it
    addArc (getIndex(vertex1), getIndex(vertex2));
    addArc (getIndex(vertex2), getIndex(vertex1));
  }
  
  /******************************************************************
    Inserts an arc from vertex1 to vertex2.
    If the vertices exist, else does not change the graph. 
    ******************************************************************/
  public void addArc (T vertex1, T vertex2){
    addArc (getIndex(vertex1), getIndex(vertex2));
  }
  
  /******************************************************************
    Helper. Inserts an edge between two vertices of the graph.
    ******************************************************************/
  private void addArc (int index1, int index2)
  {
    if (indexIsValid(index1) && indexIsValid(index2))
      arcs[index1][index2] = true;
  }
  
  
  /******************************************************************
    Removes an edge between two vertices of the graph.
    If one or both vertices do not exist, ignores the removal.
    ******************************************************************/
  public void removeEdge (T vertex1, T vertex2)
  {
    removeArc (getIndex(vertex1), getIndex(vertex2));
    removeArc (getIndex(vertex2), getIndex(vertex1));
  }
  
  
  /******************************************************************
    Removes an arc from vertex v1 to vertex v2,
    if the vertices exist, else does not change the graph. 
    ******************************************************************/
  public void removeArc (T vertex1, T vertex2){
    removeArc (getIndex(vertex1), getIndex(vertex2)); }
  
  /******************************************************************
    Helper. Removes an arc from index v1 to index v2.
    ******************************************************************/
  private void removeArc (int index1, int index2)
  {
    if (indexIsValid(index1) && indexIsValid(index2))
      arcs[index1][index2] = false;
  }
  
  
  
  /******************************************************************
    Returns the index value of the first occurrence of the vertex.
    Returns NOT_FOUND if the key is not found.
    ******************************************************************/
  private int getIndex(T vertex)
  {
    for (int i = 0; i < n; i++)
      if (vertices[i].equals(vertex))
      return i;
    return NOT_FOUND;
  }
  
  /******************************************************************
    Returns the vertex object that is at a certain index
    ******************************************************************/
  private T getVertex(int v)
  {   return vertices[v]; 
  }
  
  /******************************************************************
    Returns true if the given index is valid. 
    ******************************************************************/
  private boolean indexIsValid(int index)
  {  return ((index < n) && (index >= 0));  
  }
  
  /******************************************************************
    Retrieve from a graph the vertices x pointing to vertex v (x->v)
    and returns them onto a linked list
    ******************************************************************/
  public LinkedList<T> getPredecessors(T vertex){
    LinkedList<T> neighbors = new LinkedList<T>();
    
    int v = getIndex(vertex); 
    
    for (int i = 0; i < n; i++)
    {
      if (isArc(i,v))  
        neighbors.add(getVertex(i)); // if T then add i to linked list
    }    
    return neighbors;    
  }
  
  /******************************************************************
    * Retrieve from a graph the vertices x following vertex v (v->x)
    and returns them onto a linked list
    ******************************************************************/
  public LinkedList<T> getSuccessors(T vertex){
    LinkedList<T> neighbors = new LinkedList<T>();
    
    int v = getIndex(vertex); 
    
    for (int i = 0; i < n; i++)
    {
      if (isArc(v,i))  
        neighbors.add(getVertex(i)); // if T then add i to linked list
    }    
    return neighbors;    
  }
  
  /******************************************************************
    Returns a string representation of the graph. 
    ******************************************************************/
  public String toString()
  {
    if (n == 0)
      return "Graph is empty";
    
    String result = new String("");
    
    result += "Arcs\n";
    result += "-----\n";
    result += "i ";
    
    for (int i = 0; i < n; i++) 
    {
      result += "" + getVertex(i);
      if (i < 10)
        result += " ";
    }
    result += "\n";
    
    for (int i = 0; i < n; i++)
    {
      result += "" + getVertex(i) + " ";
      
      for (int j = 0; j < n; j++)
      {
        if (arcs[i][j])
          result += "1 ";
        else
          result += "- "; //just empty space
      }
      result += "\n";
    }
    
    return result;
  }
  
  
  /******************************************************************
    * Saves the current graph into a .tgf file.
    * If it cannot save the file, a message is printed. 
    *****************************************************************/
  public void saveTGF(String tgf_file_name) {
    try {
      PrintWriter writer = new PrintWriter(new File(tgf_file_name));
      
      //prints vertices by iterating through array "vertices"
      for (int i = 0; i < n(); i++){
        if (vertices[i] == null){
          break;
        }
        else{
          writer.print((i+1) + " " + vertices[i]);
          writer.println("");
        }
      }
      writer.print("#"); // Prepare to print the edges
      writer.println("");
      
      //prints arcs by iterating through 2D array
      for (int i = 0; i < n(); i++){
        for (int j = 0; j < n(); j++){
          if (arcs[i][j] == true){
            writer.print((i+1) + " " + (j+1));
            writer.println("");
          }
        }
      }
      writer.close();
    } catch (IOException ex) {
      System.out.println("***(T)ERROR*** The file could nt be written: " + ex);
    }
  }



// METHODS TO BE IMPLEMENTED FOR MIDTERM EXAM 3



  
  /******************************************************************
    * Clones the graph by saving the current one on the disk 
    * as TEMP.tgf using saveTGF() and creating a new one using the 
    * second constructor.
    * @return the new graph.
    * FEATURE: It does not try to delete the file from the disk
    * Creates a new AdjMatGraphPlus 
    *****************************************************************/
  public GraphPlus<T> clone () 
  {
// YOUR CODE HERE
  this.saveTGF("TEMP.tgf");
  numClone++;
  GraphPlus<T> newTemp = new AdjMatGraphPlus<T>("TEMP.tgf");
  //newTemp.saveTGF("TEMP.tgf");
  
  T[] tempV = (T[]) (new Object[n]); 
  boolean[][] tempA = new boolean[n][n];
  
  for(int i=0; i<n; i++){
   tempV[i] = vertices[i];
  } this.vertices = tempV;
  
  for(int j=0; j<n; j++){
    for(int i=0; i<n; i++){
    tempA[i][j] = arcs[i][j];
    }
  } this.arcs = tempA;
  
    //System.out.println(GraphPlus<T>); //like returning an iterator? return the traversal instead? POLYMORPHISM
    return newTemp; 
  }

  /******************************************************************
    * Checks if a vertex is a sink, (points to no other vertex)
    * @return true if the vertex is a sink, false if it is not.
    ******************************************************************/
  public boolean isSink (T vertex)
  {
    boolean s = true; 
    int v = getIndex(vertex);
    for (int i = 0; i < n; i++)
    {
      if (isArc(v,i)){  
        return false;
      } 
    }
    return s;
  }
  
  /******************************************************************
    * Retrieves the vertices that are sinks and 
    * @return all the sinks in a linked list
    ******************************************************************/
  public LinkedList<T> allSinks()
  {
    LinkedList<T> sinks = new LinkedList<T>();
    
 // YOUR CODE HERE
    for(int i=0; i<n;i++){
      if(isSink(vertices[i])){sinks.add(vertices[i]);}
    }
     return sinks;  
  }
  
  
  /******************************************************************
    * Checks if a vertex is a source, (no vertex points to it)
    * @return true if the vertex is a source, false if it is not
    ******************************************************************/
  public boolean isSource (T vertex)
  {
    boolean s = true;
    int v = getIndex(vertex);
    for (int i = 0; i < n; i++)
    {
      if (isArc(i,v)){  
        return false;
      } 
    }    
    return s;
  }
  
  /******************************************************************
    * Retrieves the vertices that are sources and 
    * @return all the sources in a linked list
    ******************************************************************/
  public LinkedList<T> allSources()
  {
    LinkedList<T> sources = new LinkedList<T>();
    for(int i=0; i<n;i++){
      if(isSource(vertices[i])){sources.add(vertices[i]);  
      }      
    }
    return sources; 
  }
  
  /******************************************************************
    * Checks if a vertex is a isolated, b/c it's source and sink
    * @return true if the vertex is isolated, false if it is not
    ******************************************************************/
  public boolean isIsolated (T vertex)
  {
    return (isSink(vertex) && isSource(vertex));

  }
  
  
  /******************************************************************
    * Topologically sort vertices of a directed acyclic graph
    * using one of the two algorithms presented in class. 
    * PREREQUISITE: The input graph must be a DAG, i.e., have NO CYCLES.
    * KNOWN BUG: It will get into an infinite loop if the graph has a cycle
    * @return the topologically sorted vertices in a linked list
    ******************************************************************/
  public LinkedList<T> topologicalSort(){
    LinkedList<T> sorted = new LinkedList<T>();
    
    //copy, such that not destructive
    //what about the other methods that directly used vertices and arc?
    //not actually remove, just decrement? or act like it is no longer there
    
//    boolean[] marked = new boolean[n];
//    for(int i=0[i<n;i++){
//     marked[i] = false;
//    }
    
    AdjMatGraphPlus<T> temp = (AdjMatGraphPlus<T>)this.clone();
    int added = 0;
    int i = 0;
    
    while(added<=temp.n()){
      if(isSource(temp.vertices[i%n])){
        temp.removeVertex(temp.vertices[i%n]);
        sorted.add(temp.vertices[i%n]);
        added++;}
      i++;
    }  
    return sorted;
  }

  
  /******************************************************************
    * Returns a LinkedList contining a DEPTH first search traversal 
    * starting at the given index. If the index is not valid, 
    * it returns an empty list
    * @return a linked list with the vertices in depth-first order
    *****************************************************************/
  public LinkedList<T> DFS(T vertex){
    int startIndex = getIndex(vertex);
    LinkedList<T> resultList = new LinkedList<T>(); 
    boolean[] marked = new boolean[n];
    for(int i=0; i<n; i++){
      marked[i] = false;
    }
    
    if(startIndex>-1){
      resultList.add(vertices[startIndex]); //iter
      marked[startIndex] = true;
    }
    
//    like levelorder
//    while node is not a sink
//    given node: get index
//    get the leftmost child, add to list
//    return to given node, check for right child, add to list
//    leftmost child of leftmost child, stop when sinks are left 
//    levelorder
    
    return resultList;
  }
  
  /******************************************************************
    * Returns a LinkedList contining a BREADTH first search traversal 
    * starting at the given index. If the index is not valid, 
    * it returns an empty list
    * @return a linked list with the vertices in breadth-first order
    *****************************************************************/
  public LinkedList<T> BFS(T vertex){
    int startIndex = getIndex(vertex);
    T currentVertex;
    LinkedList<T> resultList = new LinkedList<T>(); 
    
    if(startIndex == -1){return resultList;}
    
    boolean[] marked = new boolean[n]; 
    for(int vertexIndex=0; vertexIndex<this.n; vertexIndex++){
      marked[vertexIndex] = false;
    }
    

    
    //like preorder: iter, left, right
    //while node is not a sink
    //given node: get index, look in that row, first true is leftmost child. add this child to list, mark as visited?
    //look in the childs row for the first tree and adds leftmost to list, etc until sink, mark as visited
    //return to given, see if there is a right child (look in given nodes row)
    //if not, chose another node (best case: point pointing to and from a node at least)
    //preorder()
    //stop if there are only sources left
    
    //difference between checking left and right: left is closest to 0 in the array, first found
    //see what that node points to first (where true appears in its row first)
 
 
      return resultList;
    }
  
  
  /******************************************************************
    Testing program. 
    ******************************************************************/
    
  public static void main (String args[]){

    // Testing for Midterm 3
        
// YOUR CODE HERE
  AdjMatGraphPlus<String> one = new AdjMatGraphPlus<String>();
  System.out.println("Adding vertices A, B, and C");
  one.addVertex("A");
  one.addVertex("B");
  one.addVertex("C");
  one.addVertex("D");
  one.addVertex("E");
  one.addVertex("F");
  one.addVertex("G");
  one.addVertex("H");
  System.out.println("Adding arcs between A-B and C-A");
  one.addArc("A","B");
  one.addArc("C", "A");
  System.out.println("Adding arcs between B-D and E-B");
  one.addArc("B","D");
  one.addArc("E", "B");
  System.out.println("Adding arcs between F-C and C-G");
  one.addArc("F","C");
  one.addArc("C", "G");
  //System.out.println("Attempting to clone graph one");
  //one.clone();
  System.out.println("Topological sort of one is A, B, C: " + one.topologicalSort());
  System.out.println("Is A a sink? false: " + one.isSink("A"));
  System.out.println("Is H a source? true: " + one.isSource("H"));
  System.out.println("Is D a sink? true: " + one.isSink("D"));
//  System.out.println("Removing arc between A-B");
//  one.removeArc("A", "B");
//  System.out.println("Is A a sink? true: " + one.isSink("A"));   
  System.out.println("List all sinks: D,G,H " + one.allSinks());
  System.out.println("List all sources: E,F,H " + one.allSources());
  System.out.println("Is H isolated? true: " + one.isIsolated("H"));
  System.out.println("About to reach BFS Traversal");
//  System.out.println("BFS Traversal" + one.BFS("A"));
 
  
  
  
  
  

    
  }
}