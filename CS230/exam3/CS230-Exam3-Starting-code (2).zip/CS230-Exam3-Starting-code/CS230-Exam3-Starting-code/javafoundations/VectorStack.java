package javafoundations;
import javafoundations.exceptions.*;
import java.util.Vector;

public class VectorStack<T> implements Stack<T>{
 
  //private final int DEFAULT_CAPACITY = 10; //keep it small for testing purposes
  //private int count; //num of elements in the Vector
  private Vector<T> v; //array to hold the elements, array named stack
  
  public VectorStack()
  {
 
    v = new Vector<T>();
  }
  
  public void push (T element)
  {
    v.add(element);
    
  }
  
  public boolean isEmpty() {
    return v.isEmpty();
  }
  
  public T pop () throws EmptyCollectionException { 
    if (this.isEmpty()){
      throw new EmptyCollectionException("Pop failed. Vector is empty.");
    } else{
      return v.remove(v.size()-1);
    }
    
 
  }
  
  public T peek () throws EmptyCollectionException {
    if (this.isEmpty()){
      throw new EmptyCollectionException("Peek failed. Vector is empty.");
    }else{
      return v.lastElement();
    }
  }
  
  public int size() {
    return v.size();
  }
  
  public static void main(String [] args){
    VectorStack<String> test = new VectorStack<String>();
    test.push("5");
    test.push("7");
    test.pop();
    System.out.println(test.peek());
    
  }
  
}