for(int vertexIndex = 0; vertexIndex<this.n; vertexIndex++){
      resultList.add(vertices[startIndex]); //iter
      marked[startIndex] = true;
    }
    
    while(!resultList.isEmpty()){
      currentVertex = resultList.pop();
      resultList.add(currentVertex);
      
     for(int vertexIndex = 0; vertexIndex<n; vertexIndex++){
       if(isArc(getIndex(currentVertex), vertexIndex) && !marked[vertexIndex]){
        resultList.add(vertices[vertexIndex]);
        marked[vertexIndex] = true;
       }
     }
    }
      
//    //like levelorder
//    //while node is not a sink
//    //given node: get index
//    //get the leftmost child, add to list
//    //return to given node, check for right child, add to list
//    //leftmost child of leftmost child, stop when sinks are left 
//    //levelorder