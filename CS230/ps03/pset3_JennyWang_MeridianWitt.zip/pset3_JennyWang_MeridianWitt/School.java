/**
 * FILE NAME: School.java
 * AUTHOR: Jenny Wang & Meredian Witt
 * DATE: February 23, 2014
 * 
 * The School class stores information about a single graduate school program, including the school's name,
 * academic, research, and publications ratings (1-10). Each school object also includes an overall rating 
 * based on a weighted sum of the three individual rankings of the school. The weights are given by the user through
 * the command-line. Lastly, it also stores a rank value which holds the value on which the sorting of the schools
 * is based upon (academics, research, publications, or overall ratings).
 * */

public class School {
  private String name;
  private int academics, research, publications;
  public int overallRating, rank; // public variables because used in GradSchools class
  
  public School(String name, int academics, int research, int publications) {
    this.name = name;
    this.academics = academics;
    this.research = research;
    this.publications = publications;
  }
  
  public String getName() {
    return name;
  }
  
  public int getAcademics() {
    return academics;
  }
  
  public int getResearch() {
    return research;
  }
  
  public int getPublications() {
    return publications;
  }
  
  public int getOverallRating() {
    return overallRating;
  }
  
  public int getRank() {
    return rank;
  }
  
  // computes the overall rating based on 3 weights and sets the appropriate instance variable to that value
  public int computeRating(int weightA, int weightR, int weightP) {
    overallRating = (weightA*academics) + (weightR*research) + (weightP*publications);
    return overallRating;
  }
  
  public String toString(){
    String result = "";
    result = "Name: " + name + "\n" + "Academics: " + academics + "\n" + "Research: " + research
      + "\n" + "Publications: " + publications + "\n" + "Overall rating: " + overallRating + "\n"
      + "Current rank: " + rank + "\n";
    return result;
  }
  
  // method for testing
  public static void main(String[] args) {
    School wellesley = new School("Wellesley", 10, 10, 10);
    School berkeley = new School("UC Berkeley", 9, 9, 9);
    School mit = new School("MIT", 10, 10, 7);
    School stanford = new School("Stanford", 8, 10, 9);
    School cmu = new School("CMU", 7, 8, 6);
    
    System.out.println(berkeley);
    System.out.println(mit);
    System.out.println(stanford);
    System.out.println(cmu);
    System.out.println(wellesley);
  }
  
  
}