/**
 * FILE NAME: GradSchools.java
 * AUTHOR: Jenny Wang & Meredian Witt
 * DATE: February 23, 2014
 * 
 * The GradSchools class stores information about a collection of School objects contained in an array.
 * In the interactions panel, the user will enter weights for academics, research, and publications, 
 * and then the program will compute the overall rating for all the schools in the collection. 
 * This rating is determiend by a weighted sum of the three rating factors. Lastly, it sorts the schools according 
 * to each one of the rnaking factors and prints the results.
 * */

public class GradSchools {
  private School[] myGradSchools;
  private int maxSchools = 100; // starting length of the array
  public static int counter;  // keeps track of number of schools in the collection
  
  public GradSchools() {
    myGradSchools = new School[maxSchools];
    counter = 0;
  }
  
  public void addSchool(School s) {
    if(counter == myGradSchools.length) {  // if array has no more space
      addSpace();
    } 
    myGradSchools[counter] = s;
    counter++;
  }
  
  // helper method to increase the length of the array in order to add more School objects to it
  private void addSpace() {
    School[] temp = new School[myGradSchools.length * 2];
    for(int i = 0; i < myGradSchools.length; i++) {
      temp[i] = myGradSchools[i];
    }
    myGradSchools = temp;
  }
  
  /* uses computeRating() method from the School class to compute the overall rating for 
   * all the schools in the collection based on the three weights passed as parameters
   */
  public void computeRatings(int a, int b, int c) {
    for(int i = 0; i < counter; i++) {
      myGradSchools[i].overallRating = myGradSchools[i].computeRating(a, b, c);
    }
  }
  
  /* Based on the input factor, this method ranks all the schools in the collection by that specific factor's ratings.
   * Utilizes sortArray() and swap() to sort the array from highest (factor rating) to lowest.
   * */
  public void rankSchools(String factor) {
    
    switch(factor) {
      case "academics": 
        for(int i = 0; i < counter; i++) {
        myGradSchools[i].rank = myGradSchools[i].getAcademics();
      }
        break;
        
      case "research": 
        for(int i = 0; i < counter; i++) {
        myGradSchools[i].rank = myGradSchools[i].getResearch();
      }
        break;
        
      case "publications" :
        for(int i = 0; i < counter; i++) {
        myGradSchools[i].rank = myGradSchools[i].getPublications();
      }
        break;
        
      case "overall" :
        for(int i = 0; i < counter; i++) {
        myGradSchools[i].rank = myGradSchools[i].getOverallRating();
      }
        break;
    }
    sortArray(myGradSchools);
    System.out.println("Ranking of schools from highest to lowest using " + factor + " as a factor:");
    for(int i = 0; i < counter; i++) {
      System.out.println(myGradSchools[i].getName());
    }
    System.out.println();
  }
  
  // helper method that sorts a School array in decreasing order
  public void sortArray (School[] arrayA) {
    int minNum;    // maximum integer so far
    int minIndex;  // index of maximum integer
    int i, j;
    for (j = counter - 1; j > 0; j--) {
      minIndex = 0; 
      minNum = arrayA[0].getRank();
      for (i = 1; i <= j; i++) {
        if (arrayA[i].getRank() < minNum) {
          minNum = arrayA[i].getRank();
          minIndex = i;
        }
      }
      swap(arrayA, minIndex, j);
    }
  }
  
  // helper method that swaps two objects in a certain element of a School array
  private void swap (School[] arrayA, int i, int j) {
    School temp = arrayA[i];
    arrayA[i] = arrayA[j];
    arrayA[j] = temp;
  }
  
  public String toString() {
    String result = "";
    for(int i = 0; i < counter; i++) {
      result = result + myGradSchools[i] + "\n";
    }
    return result;
  }
  
  
  public static void main(String[] args) {
    GradSchools test = new GradSchools();
    School berkeley = new School("UC Berkeley", 9, 9, 9);
    School mit = new School("MIT", 10, 10, 7);
    School stanford = new School("Stanford", 8, 10, 9);
    School cmu = new School("CMU", 7, 8, 6);
    test.addSchool(mit);
    test.addSchool(stanford);
    test.addSchool(cmu);
    test.addSchool(berkeley);
    
    if (args.length != 3) {
      System.out.println("Please provide 3 weights (1-5) for academics, research, and publications.");
    } else {
      System.out.println("There are " + counter + " schools in the database:" + "\n");
      int aWeight = Integer.parseInt(args[0]);
      int rWeight = Integer.parseInt(args[1]);
      int pWeight = Integer.parseInt(args[2]);
      
      test.computeRatings(aWeight, rWeight, pWeight);
      System.out.println(test);
      test.rankSchools("academics");
      test.rankSchools("research");
      test.rankSchools("publications");
      test.rankSchools("overall");
      
      // testing cases from Takis' email
      GradSchools list = new GradSchools();
      School a = new School("AcademicSch", 10, 5, 3);
      School r = new School("ResearchSch", 3, 10, 5);
      School p = new School("PubsFactory", 5, 3, 10);
      School b = new School("BalancedSch", 7, 7, 7);
      list.addSchool(a);
      list.addSchool(r);
      list.addSchool(p);
      list.addSchool(b);
      list.computeRatings(aWeight, rWeight, pWeight);
      System.out.println(list);
      list.rankSchools("academics");
      
      // testing sortArray from highest to lowest
//    int[] test1 = {3, 5, 1, 2, 8, 53, 14, 0};
//    int [] test2 = {3, 5, 2, 8, 12, 57, 2};
//    int [] test3 = {1, 2, 3, 4, 5, 6, 7};
//    sortArray(test, "academics");
//    for(int i = 0; i < test3.length; i++) {
//      System.out.print(test3[i] + " ");
//    }
      
    }
  }
}

