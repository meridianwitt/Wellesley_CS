/**
 * FILE NAME: CheckingAccount.java
 * AUTHOR: Jenny Wang & Meredian Witt
 * DATE: February 23, 2014
 * 
 * The CheckingAccount class in addition has a minimum balance and an overdraft fee. These two variables are used in 
 * the withdraw method whenever balance is less than the minimum balance (overdrawn).
 * */

import java.text.DecimalFormat;

public class CheckingAccount extends Account {
  private final double minimumBalance = 100.00;
  private final double overdraftFee = 5.00;
  
  public CheckingAccount() {
    super();
  }
  
  // allows overdrafts, but fee is incurred if balance < minimumBalance
  public void withdraw(double amount) {
    balance -= amount;
    if(balance < minimumBalance) {
      balance -= overdraftFee;
      System.out.println("You have incurred an overdraft fee of $5.00. :("); // notifies user if overdrawn
    }
  }
  
  // uses Account toString() method
  DecimalFormat df = new DecimalFormat("0.00");
  public String toString() {
    String result = "";
    result = super.toString() + "Minimum Balance = $" + df.format(minimumBalance) + "\n";
    return result;
  }
  
  public static void main(String[] args) {
    DecimalFormat d = new DecimalFormat("0.00");
    
    CheckingAccount c = new CheckingAccount();
    // prints to see if initial values work
    System.out.println(c);
    
    c.withdraw(450.0);
    System.out.println("expected balance: $45.00, got: $" + d.format(c.balance)); 
    System.out.println(c);
    c.withdraw(40.0);
    System.out.println("expected balance: $0.00, got: $" + d.format(c.balance));
    System.out.println(c);
    
    CheckingAccount checking = new CheckingAccount();
    checking.deposit(100.0);
    System.out.println("expected balance: $600.00, got: $" + d.format(checking.balance)); 
    System.out.println(checking);
    checking.withdraw(50.0);
    System.out.println("expected balance: $550.00, got: $" + d.format(checking.balance)); 
    System.out.println(checking);
  }
  
}