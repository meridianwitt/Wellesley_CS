/**
 * FILE NAME: Account.java
 * AUTHOR: Jenny Wang & Meredian Witt
 * DATE: February 23, 2014
 * 
 * The abstract Account class generates a random account number and creates a starting balance. This is an abstract
 * parent class for CheckingAccount and SavingsAccount.
 * */

import java.util.Random;
import java.util.*;
import java.text.DecimalFormat;

public abstract class Account {
  private int accountNumber;
  protected double balance;
  
  public Account() {
    Random generator = new Random();
    accountNumber = generator.nextInt(99999);
    balance = 500.00;
  }
  
  // abstract method as a placeholder for child classes
  abstract public void withdraw(double amount);

  // no other code can override this method. deposit method is the same for all child classes
  public void deposit(double amount) {
   DecimalFormat df = new DecimalFormat("0.00");
    balance += amount;
    System.out.println("You have deposited $" + df.format(amount) + " into your account. :D");
  }
  
  public String toString() {
    DecimalFormat df = new DecimalFormat("0.00");
    String result = "";
    result = "Account #: " + accountNumber + "\n" +
      "Balance: $" + df.format(balance) + "\n";
    return result;
  }

  // main method does not work since class is abstract
  
}