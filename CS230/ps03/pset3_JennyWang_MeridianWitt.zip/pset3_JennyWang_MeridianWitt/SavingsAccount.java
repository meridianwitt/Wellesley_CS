/**
 * FILE NAME: SavingsAccount.java
 * AUTHOR: Jenny Wang & Meredian Witt
 * DATE: February 23, 2014
 * 
 * The SavingsAccount class has an annual interest rate and a method to recalculate the balance
 * every month adding on the monthly interest rate. This class also utilizes some NumberFormat and DecimalFormat
 * methods.
 * */

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class SavingsAccount extends Account {
  private final double annInterest = 0.1;
  
  public SavingsAccount() {
    super();
  }
  
  public void withdraw(double amount) {
    balance -= amount;
  }
  
  // void method that updates the balance every month according to the annual interest divided by 12
  public void recalculateMonthlyBalance() {
    balance += (balance * annInterest)/12.0;
  }
  
  // uses Account toString() method
  public String toString() {
    NumberFormat nf = NumberFormat.getPercentInstance();
    
    String result = "";
    result = super.toString() + "Annual Interest Rate = " + nf.format(annInterest) + "\n";
    return result;
  }
  
  public static void main(String[] args) {
    DecimalFormat df = new DecimalFormat("0.00");
    
    SavingsAccount s = new SavingsAccount();
    // print to see if initial values work
    System.out.println(s);
    
    s.recalculateMonthlyBalance();
    System.out.println("expected balance: $504.17, got: $" + df.format(s.balance));
    System.out.println(s);
    
    SavingsAccount savings = new SavingsAccount();
    savings.withdraw(1.99);
    System.out.println("expected balance: $498.01, got: $" + df.format(savings.balance));
    System.out.println(savings);
    
    SavingsAccount momoney = new SavingsAccount();
    momoney.deposit(999.99);
    System.out.println("expected balance: $1499.99, got: $" + df.format(momoney.balance));
    System.out.println(momoney);
  }
}