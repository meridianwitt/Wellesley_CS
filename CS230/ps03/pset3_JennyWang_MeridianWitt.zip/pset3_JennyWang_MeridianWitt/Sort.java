public class Sort {  
  
  /*
  * sorts the integers in the input array in decreasing order
  * 
  * The inner loop initializes the number in the first slot of the array as the maxNum and compares the next number to it. 
  * If the next slot is larger, it will swap the number out and put it at the end. 
  * The outer loop changes the position the swapped number will go to (last, next to last, etc). Overall, the algorithm
  * compares two side by side elements and places the smaller at the end of the array.
  */
  public static void sortArray (int[] arrayA) {
    int maxNum;    // maximum integer so far
    int maxIndex;  // index of maximum integer
    int i, j;
    for (j = arrayA.length - 1; j > 0; j--) {
      maxIndex = 0;
      maxNum = arrayA[0];
      for (i = 1; i <= j; i++) 
        if (arrayA[i] > maxNum) {
          maxNum = arrayA[i];
          maxIndex = i;
        }
      swap(arrayA, maxIndex, j);
    }
  }
  
/** 
  * exchanges the contents of locations i and j in the input array
  */
  private static void swap (int[] arrayA, int i, int j) {
    int temp = arrayA[i];
    arrayA[i] = arrayA[j];
    arrayA[j] = temp;
  }
  
  public static void main(String[] args) {
    int[] test1 = {3, 5, 1, 2, 8, 53, 14, 0};
    int [] test2 = {3, 5, 2, 8, 12, 57, 2};
    int [] test3 = {1, 2, 3, 4, 5, 6, 7};
    sortArray(test3);
    for(int i = 0; i < test3.length; i++) {
      System.out.print(test3[i] + " ");
    }
  
  }
}