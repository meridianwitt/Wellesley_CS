import java.util.Scanner;

/* Introduction.java
 CS230 Lab 1 
 Written by: CS230
 Modified by: Meridian Witt
 Modified date: 1/27/14
 */

public class Introduction {
  public static void main (String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.print("Enter your name:");
    String userName = scan.nextLine();
    
    System.out.print("Enter your city, state, and country separated by a space:");
    String userCity = scan.next();
    String userState = scan.next();
    String userCountry = scan.next();
    System.out.println ("Hi, my name is "+userName+".");
    System.out.println ("I am from "+ userCity + " which is in "+userState+", which is in "+userCountry+".");
    
    
    
    String name = "Meridian";
    String city = "Washington";
    String state = "D.C.";
    String country = "USA";
    String fave1 = "dance";
    String thing1 = "record the hook for a song";
    String candy1 = "a peppermint lollipop";
//    System.out.println ("Hi, my name is "+name+".");
//    System.out.println ("I am from "+ city + " which is in "+state+", which is in "+country+".");
//    System.out.println("One thing I really like to do is "+fave1+".");
//    System.out.println("One of the best things I did this break was "+thing1+".");
//    System.out.println("One of my favorite candies is "+candy1+".");
//    System.out.println(); // I add this here just for some space when executing the program
//    
  }
}






