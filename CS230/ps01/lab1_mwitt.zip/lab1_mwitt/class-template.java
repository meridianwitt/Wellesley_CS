/**   
  *   
  * FILENAME:  MyClass.java   
  * WHO:       Cat in the Hat   
  * WHEN:      September 3, 2013
  * WHAT:      Example template for defining new Java classes  
  * LAST MODIFIED:  
*/ 

// import any libraries you need here: 

// the name of the class, MyClass, should match the  
// name of the file, eg MyClass.java 
public class MyClass {     

 // Instance variable declarations go here     
 private String myStringVar;     
 private int myIntVar;     
 private double myDoubleVar;      
 
 
 /**       
   *  Constructor to create a MyClass object       
   *      
 */       
 // Note the header (sometimes called signature) of the constructor       
 //   does *not* include a return type      
 public MyClass() {        
   // create a new MyClass object
   
 }        
   
 // Instance methods go below here  
   
 /**       
   *  Comment for method1 goes here       
   *       
 */       
 private int/double/String/void method1() {          
     // This is an *instance* method
 }     
     
 /**       
   *  Comment for method2 goes here       
   *       
 */       
 private static int/double/String/void method2() 
 {  
   // this is a *class* method         
 }    
 
 public static void main (String[] args) 
 {     
   // The declaration of the main method    
   //   the main method is automatically executed    
   //   when the program is run (e.g. java MyClass)    
   //    
   //   This is the place to test this class: you can    
   //  create objects of type MyClass here and check that    
   //  your instance methods work (e.g.      
   //                  MyClass booger = new MyClass();    
   //                  booger.method1();    
   //                  booger.method2();    
   //                  MyClass cheese = new MyClass();    
   //                     ...   
   
 } // closes the main() method  
 
} // closes the MyClass class definition 
