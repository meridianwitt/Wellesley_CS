/*CS230 Assignment 1  Username.java

Author: Meridian Witt

Date Submitted: February 2, 2014

Collaborators:
Discussed how to make and roll through arrays with TA Erin.

Notes:
1. No known bugs.

2. The program works as reported in the documentation page. 
To demostrate that, I have included a soft copy of the typescript of my testing.

*/

import java.util.*; //could use scanner, array, or list...what is this for?

public class Username {
   private String firstname;
   private String lastname;
   private String fcname; // the firstclass-like username
   private int LL; //length of lastname, not sure if this is the smartest way
   final int MAX = 8;
    
   //-----------------------------------------------------------------
   //  Constructor. Sets the f and l as firstname and lastname,
   // and computes the fcname with the first character of f
   // and up to the first 7 characters of l
   //-----------------------------------------------------------------
   public Username(String f, String l) {
     // Your code goes here
     
     this.firstname = f;
     this.lastname = l;
     
     String firstLetter = (f.substring(0,1)).toLowerCase(); 
     
     if(l.length() < MAX-1){
       LL = l.length();
     } else {LL = MAX-1;}
     
     String rest = (l.substring(0,LL)).toLowerCase();
     fcname = firstLetter.concat(rest);
   }
   
   //-----------------------------------------------------------------
   //  Returns a string description of the Username.
   //-----------------------------------------------------------------
   public String toString()
   {
 // Your code goes here
     return fcname + "\t" + firstname + "\t" + lastname; 
   }
   
   //-----------------------------------------------------------------
   //  Checks for equality between this and another Username
   //-----------------------------------------------------------------
   public boolean equals (Username another){
   //Your code goes here
     if(fcname.equals(another)){
       return true; // dummy statement to pass compilation
     }else{
       return false;
     }
   }

   //-----------------------------------------------------------------
   //  This main is used as a driver for the class.
   // Note the printout that helps you see whether the program produced
   // what was expected. Make sure you maintain this testing style 
   // in your programs
   //-----------------------------------------------------------------
   
   public static void main (String[] args) {
 Username u1 = new Username ("Kathy", "Lee"); 
 System.out.println(u1.toString());
 System.out.println("expected: klee got: " + u1);
 Username u2 = new Username ("Jennifer", "Anniston"); 
 System.out.println("expected: jannisto got: " + u2);
 if (!u2.equals(u1)) System.out.println("u2 and u1 do not have the same fcname");
 Username u3 = new Username ("Kate", "Lee"); 
 System.out.println("expected: klee got: " + u3);
 if (u3.equals(u1)) System.out.println("u3 and u1 have the same fcname");
 Username u4 = new Username ("Jane", "Anniston"); 
 System.out.println("expected: jannisto got: " + u4);
 if (u4.equals(u2)) System.out.println("u4 and u2 have the same fcname");
 
  
   
  //arrays for testing.
   String[] firstnames = new String[4];
   firstnames[0] = "Annie";
   firstnames[1] = "Annmarie";
   firstnames[2] = "Zhouying";
   firstnames[3] = "Madona";
   
   String[] lastnames = new String[4];
   lastnames[0] = "Aranzamos";
   lastnames[1] = "Ha";
   lastnames[2] = "Zhang";
   lastnames[3] = "Branch";
   
  
   for (int i=0; i<4; i++){
     Username test = new Username (firstnames[i], lastnames[i]); 
     System.out.println(test.toString());
   }
   }
}
   
   

