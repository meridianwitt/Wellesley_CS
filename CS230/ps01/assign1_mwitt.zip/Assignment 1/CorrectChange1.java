/*CS230 Assignment 1  CorrectChange1.java

Author: Meridian Witt

Date Submitted: February 2, 2014

Collaborators:
Discussed object oriented formatting with TA Erin.
Discussing toString() with TA Megan. 

Notes:
1. No known bugs.

2. The program works as reported in the documentation page. 
To demostrate that, I have included a soft copy of the typescript of my testing.

*/

import java.util.Scanner;

public class CorrectChange1{
  //Instance variables
  private double cost;
  private double paid;
  private double owed;
  private int owedDollars;
  
  private int owedTens;
  private int owedFives;
  private int owedOnes;
  private int owedQuarters;
  private int owedDimes;
  private int owedNickels;
  private int owedPennies;
  
  private int owedChange;
  private int change1;
  private double change2;
  private double coins1;
  
  //Constructor
  public CorrectChange1(){
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter the total cost amount");
    cost = scan.nextDouble();
    
    System.out.println("Enter the total amount paid");
    paid = scan.nextDouble();
    
    owed = paid - cost;
    
   owedDollars = (int)Math.floor(owed); //the dollar amount
   owedTens = owedDollars/10;
   change1 = owedDollars%10;
   owedFives = change1 / 5;
   owedOnes = change1%5;
    
   owedChange = (int)((owed - (owedTens*10) - (owedFives*5) - owedOnes)*100); //the change amount in whole numbers
   owedQuarters = (int)owedChange/25;
   coins1 = (owedChange%25); //the left over after quarters 
   owedDimes = (int)(coins1/10);
   change2 = (coins1%10); //the left over after dimes
   owedNickels = (int)(change2 / 5);
   owedPennies = (int)(change2%5); // the left over after nickels = pennies
  }
  
  //toString method
  public String toString(){
    if(paid>cost){
      String s = "";
      if(owedTens > 0){
        s = s + (owedTens + ((owedTens == 1) ? " Hamilton" : " Hamiltons")) + "\n";
      } 
      if (owedFives > 0){
        s = s +(owedFives + ((owedFives == 1) ? " Lincoln" : " Lincolns")) + "\n";
      }
      if(owedOnes > 0){
        s = s + (owedOnes + ((owedOnes == 1) ? " Washington" : " Washingtons")) + "\n"; 
      }
      if (owedQuarters>0){
        s = s + (owedQuarters + ((owedQuarters == 1) ? " quarter" : " quarters")) + "\n";
      }
      if(owedDimes>0){
        s = s + (owedDimes + ((owedDimes == 1) ? " dime" : " dimes")) + "\n"; 
      }
      if(owedNickels>0){
        s = s + (owedNickels + ((owedNickels == 1) ? " nickel" : " nickels")) + "\n";
      }
      if(owedPennies>0){
        s = s + (owedPennies + ((owedPennies == 1) ? " penny" : " pennies")) + "\n"; 
      }
      return s;
    } else {
      return "You did not pay enough!";
    }
  }
  
  public static void main(String[] args){
    CorrectChange1 test = new CorrectChange1();
    System.out.println(test);
  }  
}

