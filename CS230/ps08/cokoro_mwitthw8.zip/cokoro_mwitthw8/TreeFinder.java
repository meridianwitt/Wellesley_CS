public class TreeFinder{
  public static void main(String[] args){
   //create instance of class
   //driving method like diagnose
  }
}