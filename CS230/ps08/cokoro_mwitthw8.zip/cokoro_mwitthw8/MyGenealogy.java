import javafoundations.*;
import java.util.*; 

public class MyGenealogy{
  
    public static void main (String[]args) { 
      GenealogyTree myTree = new GenealogyTree<String>("Meridian");
      myTree.setPater("Meridian","Clayton"); 
      myTree.setMater("Meridian","Karla");
      myTree.setPater("Clayton","Alex");
      myTree.setMater("Clayton","Gertrude");
      myTree.setPater("Karla","Bob");
      myTree.setMater("Karla","Gladys");
      myTree.setPater("Alex","Dennis");
      myTree.setMater("Alex","Jan");
      myTree.setPater("Gertrude","Mike");
      myTree.setMater("Gertrude","Michaela");
      myTree.setPater("Bob","Kevin");
      myTree.setMater("Bob","Kayla");
      myTree.setPater("Gladys","Jack");
      myTree.setMater("Gladys","Jill");
      System.out.println("My Genealogy contains: " + myTree.size() + " members."); 
      System.out.println(myTree); 
      System.out.println("Clayton offspring is Meridian: " + myTree.getOffspring("Clayton"));
      System.out.println("Alex offspring is Clayton: " + myTree.getOffspring("Alex"));
      System.out.println("Glady offspring is Karla: " + myTree.getOffspring("Gladys"));
      System.out.println("Your father is Clayton : " + myTree.getPater("Meridian")); 
      System.out.println("Your mother is Karla : " + myTree.getMater("Meridian")); 
      System.out.println("Your paternal grandfather is Alex: " + myTree.getPater(myTree.getPater("Meridian"))); 
      System.out.println("Your maternal grandmother is Gladys: " + myTree.getMater(myTree.getMater("Meridian"))); 
      System.out.println("Your paternal grandmother is Gertrude: " + myTree.getMater(myTree.getPater("Meridian"))); 
      System.out.println("Your maternal grandfather is Bob: " + myTree.getPater(myTree.getMater("Meridian")));
      System.out.println("Gertude and Alex are in-laws true: " + myTree.inLaws("Gertrude","Alex")); 
      System.out.println("Bob and Karla are NOT in-laws false: " + myTree.inLaws("Bob","Karla"));
      
    } 
  } 
