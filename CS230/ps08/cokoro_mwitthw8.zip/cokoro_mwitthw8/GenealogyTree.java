
import java.util.Iterator;
import javafoundations.*;
import javafoundations.exceptions.*;

public class GenealogyTree<T> implements AncestryTree<T>, Iterable<T>{
  
//Instance variable
  protected T cotu;
  private T[] tree; 
  private T root; 
  private int DEFAULT_CAPACITY = 10; 
  
  //CONSTRUCTOR: Create a 1-argument constructor that sets the root of a new tree
  public GenealogyTree(T element){
    cotu = element;  
    tree = (T[])(new Object[DEFAULT_CAPACITY]); 
    tree[0]= (element);
  }
  
//Getter method returns the element stored in the root (aka CoTU) of the tree.
  public T getCoTU(){ //Center of The Universe
    return (T)cotu; 
  } 
//  Returns the member that is the offspring of target.
//  Returns null as the offspring of the root.
  public T getOffspring(T target){ // This is "parent" in tree terminology
    T result = null;
    int cotuIndex = findIndex(tree[0]); 
    int index = findIndex(target);
    if( cotuIndex== index){ return result; } 
    else if(index != -1){result = tree[(index-1)/2];} 
    return result; 
    } 
  
//  Returns the member that is the left child of target.
//  Returns null if the left child does not exist.

  public T getPater(T target){ // Paternal ancestors are on the left
    T result = null;
    int index = findIndex(target); 
    if(index != -1){result = tree[(2*index)+1];}; 
    return result;  
  }
  
  //  Sets the left child of the tree target to lchild.
  //  It throws an exception if target is not already in the tree
  //  Finds the index of the target and places the child in the correct place accordingly 2n+1 spaces away
  public void setPater(T target, T lchild){
    try{
    int index = findIndex(target);
    if(tree.length==size()){
      increaseSize(); 
      tree[(2*index)+1] = lchild;
    } else {
      tree[(2*index)+1] = lchild;
    }
    } catch (ArrayIndexOutOfBoundsException ex){
      System.out.println("Pater target " + target + " not found.");
    }
  } 
  
  //  Returns the element that is the right child of target.
  //  Returns null if the right child does not exist
  public T getMater(T target){ // Maternal ancestors are on the right
    T result = null;
    int index = findIndex(target); 
    if(index != -1){result = tree[(2*index)+2];}; 
    return result; 
  } 
  
//  Sets the right child of target to rchild.
//  It throws an exception if target is not already in the tree
//  Finds the index of the target and places the child in the correct place accordingly 2n+2 spaces away
  public void setMater(T target, T rchild){ 
    try{
      int index = findIndex(target);
      if(tree.length==size()){
        increaseSize(); 
        tree[(2*index)+2]= rchild;
      } else {
        tree[(2*index)+2]= rchild;
      }
    } catch (ArrayIndexOutOfBoundsException ex){
      System.out.println("Mater target " + target + " not found.");
    }
  }
  
//  Returns true if the tree contains an element that
//  matches the specified target element and false otherwise.
  public boolean appears (T target){
    boolean b =false; 
    if (findIndex(target)> -1)
      b = true; 
    return b; 
    
  } 
  
//  Returns the string representation of the binary tree,
//   one line per level.
  public String toString(){
    Iterator <T> iter = byGenerations(); //iterates by level order
    int counter = 0; 
    int row = 1; 
    String s = " "; 
    while(iter.hasNext()){ 
      if(counter== row){
        s+= "\n"; 
        row = row*2; //number of members per row doubles as the levels increase
        counter= 0; 
      } else{
        s+= iter.next() + " ";
         counter++; 
      }
    }
    return s; 
  }
  
// Returns true if the two members share a grandchild,
  // and false if they are not or if a shared grandchild does not exist
  // Two grandparents that share a grandchild are "inLaws"
  public boolean inLaws(T gp1, T gp2){ 
    try{
      return ((getOffspring(getOffspring(gp1)).equals(getOffspring(getOffspring(gp2)))));
    } catch (NullPointerException ex) {
      System.out.println(gp1 + "and/or" + gp2 + "are not found."); 
      return false;
    }
  }

//  Returns the number of members in this ancestral tree.
  public int size() {
    int count = 0; 
    for ( int i =0; i < tree.length; i++){ 
      if(tree[i] !=null)
        count++; 
    } 
    return count; 
  }
  
// Returns an iterator that contains a level-order traversal
// on the ancestral tree.
  public Iterator<T> byGenerations(){
    ArrayIterator<T> iter = new ArrayIterator<T>(); 
    for( int i = 0; i < size(); i++){ 
      iter.add (tree[i]);  //going through the array as levelorder
    }
    return iter;
  }
  
  public Iterator<T> iterator() {
    return byGenerations();
  }
  
  //Private helper method to expand the array and thus the tree
  private void increaseSize(){ 
    T[] temp= (T[])(new Object[tree.length*2]);
    for(int i=0; i<size(); i++){
      temp[i] = tree[i];  
    }
    tree = temp; 
  }
  
  //Private method to findIndex of T, speeds up the getters and setters
  private  int findIndex(T target){ 
    int treeIndex = -1; 
    for( int i = 0; i< size(); i++){ 
      if(tree[i]== target){ 
        treeIndex = i;
      } 
    } 
    return treeIndex; 
  } 

  public static void main(String [] args){  
    GenealogyTree<String>tree = new GenealogyTree("T");
    //System.out.println(tree.getCoTU());
    //System.out.println(tree.appears("z"));
    //tree.setPater("A", "Z");
    tree.setPater("T","Y"); 
    tree.setMater("T","E");
    tree.setPater("Y","P");
    tree.setMater("Y","M");
    tree.setPater("E","B");
    tree.setMater("E","D");
    tree.setPater("P","A");
    tree.setMater("P","C");
    tree.setPater("M","F");
    tree.setMater("M","G");
    tree.setPater("B","H");
    tree.setMater("B","I");
    tree.setPater("D","J");
    tree.setMater("D","K");
    System.out.println("My Genealogy contains: " + tree.size() + " members."); 
    System.out.println(tree); 
    //System.out.println(tree.appears("T"));
    System.out.println("Y offspring is T: " + tree.getOffspring("Y"));
    System.out.println("E offspring is T: " + tree.getOffspring("E"));
    System.out.println("E offspring is T: " + tree.getOffspring("E"));
    System.out.println("Your father is Y : " + tree.getPater("T")); 
    System.out.println("Your mother is E : " + tree.getMater("T")); 
    System.out.println("Your paternal grandfather is P: " + tree.getPater(tree.getPater("T"))); 
    System.out.println("Your maternal grandmother is D: " + tree.getMater(tree.getMater("T"))); 
    System.out.println("Your paternal grandfather is A: " + tree.getPater(tree.getPater(tree.getPater("T")))); 
    System.out.println("Your maternal grandmother is K: " + tree.getMater(tree.getMater(tree.getMater("T"))));
    System.out.println("P and B are in-laws true: " + tree.inLaws("P","B")); 
    System.out.println("P and E are NOT in-laws false: " + tree.inLaws("P","E"));
    
  } 
}