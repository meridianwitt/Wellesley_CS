//*******************************************************************
//  BTNode.java       Java Foundations
//
//  Represents a node in a binary tree with a left and right child.
//  Therefore this class also represents the root of a subtree.
//*******************************************************************

package javafoundations;

import java.util.*; 
public class BTNode<T>
{
  protected T element;
  protected BTNode<T> left, right;
  
  //-----------------------------------------------------------------
  //  Creates a new tree node with the specified data.
  //-----------------------------------------------------------------
  public BTNode (T element)
  {
    this.element = element;
    left = right = null;
  }
  
  //-----------------------------------------------------------------
  //  Returns the element stored in this node.
  //-----------------------------------------------------------------
  public T getElement()
  {
    return element;
  }
  
  //-----------------------------------------------------------------
  //  Sets the element stored in this node.
  //-----------------------------------------------------------------
  public void setElement (T element)
  {
    this.element = element;
  }
  
  //-----------------------------------------------------------------
  //  Returns the left subtree of this node.
  //-----------------------------------------------------------------
  public BTNode<T> getLeft()
  {
    return left;
  }
  
  //-----------------------------------------------------------------
  //  Sets the left child of this node.
  //-----------------------------------------------------------------
  public void setLeft (BTNode<T> left)
  {
    this.left = left;
  }
  
  //-----------------------------------------------------------------
  //  Returns the right subtree of this node.
  //-----------------------------------------------------------------
  public BTNode<T> getRight()
  {
    return right;
  }
  
  //-----------------------------------------------------------------
  //  Sets the right child of this node.
  //-----------------------------------------------------------------
  public void setRight (BTNode<T> right)
  {
    this.right = right;
  }
  
  //-----------------------------------------------------------------
  //  Returns the element in this subtree that matches the
  //  specified target. Returns null if the target is not found.
  //-----------------------------------------------------------------
  public BTNode<T> find (T target)// we return a BTNode instead of true or faslse 
  {
    BTNode<T> result = null;// return null if the the target is not found 
    
    if (element.equals(target))
      result = this; // returns the first element/ or root node 
    else
    {
      if (left != null)
        result = left.find(target);
      if (result == null && right != null) // while right is null and there is still no result, check to see if there is a target 
        result = right.find(target);
    }
    
    return result;
  }
  
  //-----------------------------------------------------------------
  //  Returns the number of nodes in this subtree.
  //-----------------------------------------------------------------
  public int count()
  {
    int result = 1;
    
    if (left != null)
      result += left.count();// Left hand side:  increments the counter if the element is not null 
    
    if (right != null)
      result += right.count();// Right hand side:increments the counter if the element is not null
    
    return result;
  }
  
  //-----------------------------------------------------------------
  //  Performs an inorder traversal on this subtree, updating the
  //  specified iterator.
  //-----------------------------------------------------------------
  public void inorder (ArrayIterator<T> iter)
  {// Inorder: Is starting from the left element. Example: abc gets bac, left- middle-right 
    if (left != null)
      left.inorder (iter);
    
    iter.add (element);
    
    if (right != null)
      right.inorder (iter);
  }
  
  //-----------------------------------------------------------------
  //  The following methods are left as programming projects.
  //-----------------------------------------------------------------
  public void preorder (ArrayIterator<T> iter) {
    // Preorder: Is starting from the left element. Example: abc gets bca, left-right-middle  
    iter.add (element);
    if(left != null) 
      left.preorder(iter); 
    
    if(right != null)
      right.preorder(iter); 
    
    
  }
  
  public void postorder (ArrayIterator<T> iter) {
    // Postorder: Is starting from the middle element. Example: abc gets abc, left-right-middle  
    if(left != null) 
      left.preorder(iter); 
    
    if(right != null)
      right.preorder(iter);
    
    iter.add (element);
  }
  
  
  public int height() {// a binary tree is not a full binary tree 
    
    if( left==null && right ==null) return 0; 
    int l = 0;  
    int r = 0;  
    if( left != null ) l= left.height(); 
    if(right !=null) r = right.height(); 
    
      return Math.max(l, r) + 1;
  }
  
  public void spin(){
    BTNode<T> temp = new BTNode<T>(element); 
    
    temp = this.getLeft(); 
    left = this.getRight(); 
    right = temp; 
    if( left != null)
      left.spin(); 
    if(right != null)
      right.spin(); 
  }
  
  public String toString(){ 
    String s = " "; 
    s+= element;  
  return s; 
  } 
  
  public static void main(String[] args) {
    BTNode<String> one = new BTNode<String>("one");
    BTNode<String> two = new BTNode<String>("two");
    
    BTNode<String> three = new BTNode<String>("three");
    BTNode<String> four = new BTNode<String>("four");
    
    ArrayIterator<String> it = new ArrayIterator<String>();
    
    one.setLeft(two);
    one.setRight(three);
    
    one.inorder(it);
    
    one.setLeft(two);
    one.setRight(three);
    // (one.getRight()).setLeft(four);
    
    one.inorder(it);
    while (it.hasNext()) {
     //System.out.println(it.next());
      
      
    }
  }
} 
