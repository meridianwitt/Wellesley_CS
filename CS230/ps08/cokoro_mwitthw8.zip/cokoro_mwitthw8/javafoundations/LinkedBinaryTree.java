//*******************************************************************
//  LinkedBinaryTree.java       Java Foundations
//
//  Implements a binary tree using a linked representation.
//*******************************************************************

package javafoundations;

import java.util.Iterator;
import javafoundations.*;
import javafoundations.exceptions.*;

public class LinkedBinaryTree<T> /*implements BinaryTree<T>*/ 
{
  protected BTNode<T> root;
  
  //-----------------------------------------------------------------
  //  Creates an empty binary tree.
  //-----------------------------------------------------------------
  public LinkedBinaryTree()
  {
    root = null;
  }
  
  //-----------------------------------------------------------------
  //  Creates a binary tree with the specified element as its root.
  //-----------------------------------------------------------------
  public LinkedBinaryTree (T element)
  {
    root = new BTNode<T>(element);
  }
  
  //-----------------------------------------------------------------
  //  Creates a binary tree with the two specified subtrees.
  //-----------------------------------------------------------------
  public LinkedBinaryTree (T element, LinkedBinaryTree<T> left,
                           LinkedBinaryTree<T> right)
  {
    root = new BTNode<T>(element);
    root.setLeft(left.root);
    root.setRight(right.root);
  }
  
  //-----------------------------------------------------------------
  //  Returns the element stored in the root of the tree. Throws an
  //  EmptyCollectionException if the tree is empty.
  //-----------------------------------------------------------------
  public T getRootElement() {
    if (root == null)
      throw new EmptyCollectionException ("Get root operation "
                                            + "failed. The tree is empty.");
    
    return root.getElement();
  }
  
  //-----------------------------------------------------------------
  //  Returns the left subtree of the root of this tree.
  //-----------------------------------------------------------------
  public LinkedBinaryTree<T> getLeft() {
    if (root == null)
      throw new EmptyCollectionException ("Get left operation "
                                            + "failed. The tree is empty.");
    
    LinkedBinaryTree<T> result = new LinkedBinaryTree<T>();// Why do we call this a LinkedBinary Tree object instead of a BTNode 
    result.root = root.getLeft();
    
    return result;
  }
  
  //-----------------------------------------------------------------
  //  Returns the element in this binary tree that matches the
  //  specified target. Throws a ElementNotFoundException if the
  //  target is not found.
  //-----------------------------------------------------------------
  public T find (T target) {
    BTNode<T> node = null;
    
    if (root != null)
      node = root.find(target);
    
    if (node == null)
      throw new ElementNotFoundException("Find operation failed. "
                                           + "No such element in tree.");
    
    return node.getElement();
  }
  
  //-----------------------------------------------------------------
  //  Returns the number of elements in this binary tree.
  //-----------------------------------------------------------------
  public int size() {
    int result = 0;
    
    if (root != null)
      result = root.count();
    
    return result;
  }
  
  //-----------------------------------------------------------------
  //  Populates and returns an iterator containing the elements in
  //  this binary tree using an inorder traversal.
  //-----------------------------------------------------------------
  public Iterator<T> inorder() {
    ArrayIterator<T> iter = new ArrayIterator<T>();
    
    if (root != null)
      root.inorder (iter);
    
    return iter;
  }
  
  //-----------------------------------------------------------------
  //  Populates and returns an iterator containing the elements in
  //  this binary tree using a levelorder traversal.
  //-----------------------------------------------------------------
  public Iterator<T> levelorder() {
    LinkedQueue<BTNode<T>> queue = new LinkedQueue<BTNode<T>>();
    ArrayIterator<T> iter = new ArrayIterator<T>();
    
    if (root != null) {
      queue.enqueue(root);
      while (!queue.isEmpty()) {
        BTNode<T> current = queue.dequeue();
        
        iter.add (current.getElement());
        
        if (current.getLeft() != null)
          queue.enqueue(current.getLeft());
        if (current.getRight() != null)
          queue.enqueue(current.getRight());
      }
    }
    return iter;
  }
  
  //-----------------------------------------------------------------
  //  Satisfies the Iterable interface using an inorder traversal.
  //-----------------------------------------------------------------
  public Iterator<T> iterator() {
    return inorder();
  }
  
  //-----------------------------------------------------------------
  //  The following methods are left as programming projects.
  //-----------------------------------------------------------------
  
  public String toString() {
    Iterator<T> iter = new ArrayIterator<T>(); // create the "pipe"
    String s = " "; 
    if( root == null)
      s+= "This root is empty."; 
    iter = preorder(); // populate the array 
    while( iter.hasNext()){ // empty the array 
      s+=iter.next() +" " ;// emptying into s 
    }
    return s; 
  }

  public LinkedBinaryTree<T> getRight() {
    if(root == null)
      throw new EmptyCollectionException("Error: Your tree is empty"); 
    LinkedBinaryTree<T> result =new LinkedBinaryTree<T>(); 
    result= getRight(); 
    return result; 

  }
  
  public boolean contains (T target) {
    boolean result; 
      if(root == null)
      throw new EmptyCollectionException("Error: Your tree is empty"); 
    root.find(target); 
    
    return (root.find(target)!=null);
    
  }
  
  public boolean isEmpty() {
    return(size()==0); 

  }
  
  public Iterator<T> preorder() {
    ArrayIterator <T> iter = new ArrayIterator<T>(); 
    if( root !=null)
      root.preorder(iter); 
    return iter; 

  }
  
  public Iterator<T> postorder() {
    ArrayIterator <T> iter = new ArrayIterator<T>(); 
    if( root !=null)
      root.postorder(iter); 
    return iter; 

  }
//  
//  public int height() {
//   
//
//  }
//  
//  public void spin() {
//
//  }
  public static void main (String [] args){
    LinkedBinaryTree<String> g1 = new LinkedBinaryTree<String>("chimuanya");
    LinkedBinaryTree<String> g2 = new LinkedBinaryTree<String>("chibuzo"); 
    LinkedBinaryTree<String> g3 = new LinkedBinaryTree<String>("chuby");
    LinkedBinaryTree<String> g4 = new LinkedBinaryTree<String>("ugo");
    LinkedBinaryTree<String> g5 = new LinkedBinaryTree<String>("ama");
    LinkedBinaryTree<String> g6 = new LinkedBinaryTree<String>("ony");
    LinkedBinaryTree<String> g7 = new LinkedBinaryTree<String>("obi");
    LinkedBinaryTree<String> g8 = new LinkedBinaryTree<String>("mommy");
    LinkedBinaryTree<String> g9 = new LinkedBinaryTree<String>("sarah");
    LinkedBinaryTree<String> g10 = new LinkedBinaryTree<String>("livy");
    LinkedBinaryTree<String> g11 = new LinkedBinaryTree<String>("emma");
   
    
    
    LinkedBinaryTree<String> g12= new LinkedBinaryTree<String>("Related?", g10, g11);
    LinkedBinaryTree<String> g13= new LinkedBinaryTree<String>("Related?", g4, g6);
    LinkedBinaryTree<String> g14= new LinkedBinaryTree<String>("Sibilings", g12, g3);
//    LinkedBinaryTree<String> g14= new LinkedBinaryTree<String>(g11, g5, g6);
  
    
    System.out.println(g12);
    System.out.println(g14);
//    System.out.println(g2);
//    System.out.println(g2.contains("sad")); 
//    System.out.println(g3.contains("Green")); 
     System.out.println(g12.contains("ony")); 
    
    
  } 
}

