/**************************************************************************
 * Name: Vigenere
 * Authors: Meridian Witt and Meredith McCormack-Mager
 * Date: 9 March 2014
 * This program creates a Vigenere object that takes a message and a
 * password via a dialog box. When prompted, it encrypts the message and
 * then decrypts it using a Vigenere cipher.
 **************************************************************************/

import javax.swing.JOptionPane;

public class Vigenere{ //implements encryptable

 //instance variables
 private String password; //determines the shifts
 private String given; //word to be encrypted
 private String encrypted; //saving result
 private String decrypted; //saving result
 
 /**************************************************************************
 * Constructor for Vigenere. This method takes a password and a message,
 * and adjusts the message to remove all spaces and change all letters
 * to upper case.
 **************************************************************************/
 public Vigenere(String password, String given){ //take password and given
  this.password = password.toUpperCase();
  this.given = given.toUpperCase().replaceAll(" ", ""); 
  this.encrypted = "";
  this.decrypted = "";
 }
 
  /**************************************************************************
 * This method accesses the "given" instance variable. It is used for
 * testing in VigenereTest.
 **************************************************************************/
 public String getGiven(){
  return given;
 }
 
  /**************************************************************************
 * This method encrypts the message using the password. It uses an array to 
 * store all of the shifts used as indicated in the password. It calls
 * changeLetter to encrypt each letter inside a for loop for the entire
 * message.
 **************************************************************************/
 public String encrypt(){
  //loop to count the number of characters in the password = the number of shifts (given%password)
   int passwordLength = password.length();
   int[] shiftHolder = new int[passwordLength];
   for (int j = 0; j <passwordLength; j++){
     shiftHolder[j] = (int)(password.charAt(j)-'A'); //fills int array with the corresponding int shifts for each letter
   }
   for (int i = 0; i<given.length();i++) {
    int shiftNumber = i%passwordLength; //number of times we want it to loop
    int shift = shiftHolder[shiftNumber]; //accesses the shift in the array
    char temp = changeLetter(given.charAt(i), shift);
    encrypted += temp;
   }
   return encrypted;
 }
 
  /**************************************************************************
 * This method does the shifting for encrypt and decrypt. It adjusts the
 * alphabet so that 0 corresponds to A, 1 to B, etc. Then it uses modular 
 * arithmetic to assign a new letter. Finally, it adjusts back to the
 * unicode relation between numbers and chars.
 **************************************************************************/
private char changeLetter(char letter, int shift){
  int temp = (letter + shift - 'A');
  temp = (temp+ 26)%26; //added 26 to keep the numbers positive
  temp = temp + 'A';
  return (char)(temp);
}

 /**************************************************************************
 * This is the same method as encrypt, but with negative shifts. Used to decrypt.
 **************************************************************************/

public String decrypt(){
  int passwordLength = password.length();
  int[] shiftHolder = new int[passwordLength];
  for (int j = 0; j <passwordLength; j++){
    shiftHolder[j] = (int)(password.charAt(j)-'A');
  }
  for (int i = 0; i<encrypted.length();i++) {
    int shiftNumber = i%passwordLength; //number of times we want it to loop, helper method to shift around alphabet?
    int shift = -(shiftHolder[shiftNumber]); //negative shifts here
    //System.out.println("This is the shift: " + shift);
    char temp = changeLetter(encrypted.charAt(i), shift);
    decrypted += temp;
  }
  return decrypted;
}

 /**************************************************************************
 * Main method: This main method drives the program. It creates the dialog 
 * box that prompts entering the message, password, and decrypting. 
 **************************************************************************/

public static void main(String[] args){
  String given, password; 
  int again;
  given = JOptionPane.showInputDialog("What is the message?");
  password = JOptionPane.showInputDialog("What is the password?");
  Vigenere test = new Vigenere(password, given);
  //test.shift();
  //System.out.println(test.encrypted);
  
  
  //encrypted = test.shift();
  JOptionPane.showMessageDialog(null, test.encrypt());
  again = JOptionPane.showConfirmDialog(null, "Do you want it decrypted?");
  if (again == JOptionPane.YES_OPTION){
    JOptionPane.showMessageDialog(null, test.decrypt());
  }
  
  
  //again = JOptionPane.showConfirmationDialog(null, "Do another?")  
}
}