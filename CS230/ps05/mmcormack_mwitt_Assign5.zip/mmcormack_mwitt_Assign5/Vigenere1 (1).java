import javax.swing.JOptionPane;

public class Vigenere1{ //implements encryptable
 //instance variables
 private String password;
 private String given;
 private String encrypted;
 
 public Vigenere1(String password, String given){ //take password and given
  this.password = password;
  this.given = given;
  this.encrypted = "";
 }
 
 public String shift(){
  //loop to count the number of characters in the password = the number of shifts (given%password)
   int passwordLength = password.length();
   int[] shiftHolder = new int[passwordLength];
   for (int j = 0; j <passwordLength; j++){
     shiftHolder[j] = (int)(password.charAt(j)-'A');
   }
   for (int i = 0; i<given.length();i++) {
    int shiftNumber = i%passwordLength; //number of times we want it to loop, helper method to shift around alphabet?
    int shift = shiftHolder[shiftNumber];
    char temp = changeLetter(given.charAt(i), shift);
    encrypted += temp;
   }
   return encrypted;
 }
 
private char changeLetter(char letter, int shift){
  int temp = (letter + shift - 'A');
  temp = temp%26;
  temp = temp + 'A';
  return (char)(temp);
}

 public static void main(String[] args){
   String given, password;
   given = JOptionPane.showInputDialog("What is the message?");
   password = JOptionPane.showInputDialog("What is the password?");
   Vigenere test = new Vigenere(password, given);
   //test.shift();
   //System.out.println(test.encrypted);
   
    
    //encrypted = test.shift();
    JOptionPane.showMessageDialog(null, test.shift());
    //again = JOptionPane.showConfirmationDialog(null, "Do another?")  
 }
}