 /**************************************************************************
 *Name: Cyberspace
 * Authors: Meridian Witt and Meredith McCormack-Mager
 * Date: 9 March 2014
 * Purpose: In accessing URLs read from a file or from standard input, Cyberspace 
 * collects the URLs as Webpage objects. These objects are collected and 
 * sorted in an array. 
 **************************************************************************/

import java.io.*;
import java.net.URL;
import java.util.*;

public class Cyberspace {
  private Webpage [] web;
  private int counter;
  private final int START = 10;
  private final int MORE = 5;

   /**************************************************************************
 *Constructor: This method creates an array to hold 10 Webpage objects and sets
 *  the counter as 0.
 **************************************************************************/
  
  public Cyberspace(){
    web = new Webpage[START];
    counter = 0;
  }
  
   /**************************************************************************
 *ToString: This method creates a string representation of all the Webpage
 * objects in the array.
 **************************************************************************/
  
  public String toString(){
    String print = "Results from visiting " + counter + " pages.";    for (int i = 0; i < counter; i ++){
      print += "\n" + web[i];
    }
    return print;
  }
  
   /**************************************************************************
 *If necessary, addToList increases the size of the array before adding a new object
 * to the array. The objects are added in order using the compareTo method. 
 **************************************************************************/
  
  public void addToList(Webpage add){
    if (counter == web.length) addMore();
    int index = 0;
    for (int i = 0; i < counter; i++){
      if (web[i].compareTo(add) == -1){
        index = i + 1;
      }
    }
    for (int i = counter; i > index; i--){
      web[i] = web[i-1];
    }
    web[index] = add;
  }
  
   /**************************************************************************
 *This method reads standard input, using a space between URLs as a delimiter.
 * It also takes Ctrl D as null and the end of the list.
 **************************************************************************/
  
  public void readFromKeyboard(){
    Scanner scan = new Scanner(System.in);
    System.out.println("Please enter URLs (without spaces) below; end your list with ctrl-D."); //enter between each input
    while (scan.hasNextLine()){ //Ctrl D is recognized as null or empty string
      Webpage next = new Webpage(scan.next());
      next.countLinesWeb();
      addToList(next);
      counter++;
      //System.out.println(next);
    }
    scan.close();
  }
  
     /**************************************************************************
 *This method reads file input. Throws FileNotFound exception if no file is found.
 **************************************************************************/
  
  public void readFromFile(String file){
    try{
     Scanner scan = new Scanner(new File(file));
      while (scan.hasNextLine()){
        Webpage next = new Webpage(scan.next());
        next.countLinesWeb();
        //System.out.println(next);
        addToList(next);
        counter++;
      }
       scan.close();
    }
      catch (FileNotFoundException e){
        System.out.println("File not found.");
      }     
     
    }
  
     /**************************************************************************
 *Helper method to addToList to increase the size of the array.
 **************************************************************************/
  
  private void addMore(){
    Webpage[] temp = new Webpage[counter + MORE];
    for (int i = 0; i < counter; i++){
      temp[i] = web[i];
    }
    web = temp;
  }
  
 /**************************************************************************
 *Main method: This method drives the program. It creates a Cyberpace object, 
 * takes input according to the number of arguments given in the Interaction Console,
 * and prints the result. 
 **************************************************************************/
  
  public static void main(String[] args){
    Cyberspace test = new Cyberspace();
    if (args.length == 0) test.readFromKeyboard();
    if (args.length == 1) test.readFromFile(args[0]);
    System.out.println(test);
  }
}