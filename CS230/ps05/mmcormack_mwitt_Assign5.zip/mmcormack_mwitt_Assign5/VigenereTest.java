public class VigenereTest{
  public static void main(String[] args){
   Vigenere test = new Vigenere("Cat","Meridian");
   Vigenere test2 = new Vigenere("kitTen", "Meridian Witt");
   Vigenere test3 = new Vigenere("cat", "Attack at dawn");
   
   System.out.println("Original: " + test.getGiven() + "\tEncrypted: " + test.encrypt());
   System.out.println("Decrypted: " + test.decrypt());
   System.out.println("Original: " + test2.getGiven() + "\tEncrypted: " + test2.encrypt());
   System.out.println("Decrypted: " + test2.decrypt());
   System.out.println("Original: " + test3.getGiven() + "\tEncrypted: " + test3.encrypt());
   System.out.println("Decrypted: " + test3.decrypt());
  }
}