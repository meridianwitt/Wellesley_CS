  import java.util.Scanner;
  import java.io.*;  // Java I/O package
  import java.net.*; // Java web package

  public class FileOpsScanner {
    
    /* Read in the contents of a file line by line,
     * and print out each line after it is read in.
     * Stop when the end of the file is reached.
     */
    public static void displayFile(String inFileName) {
      try {
        Scanner fileScan = new Scanner (new File(inFileName));
        while (fileScan.hasNext())
          {
             String line = fileScan.nextLine();
             System.out.println (line);
             System.out.println();
          }
      } catch (IOException ex) {
        System.out.println(ex);
      }
    }
    
    /* Read in the contents of a web page line by line,
     * and print out each line after it is read in.
     * Stop when the end of the web page is reached.
     */
    public static void displayWebPage (String urlName) {
      try {
        URL u = new URL(urlName);
        Scanner urlScan = new Scanner( u.openStream() ); // will throw exception
        while (urlScan.hasNext())
          {
             String line = urlScan.nextLine();
             System.out.println (line);
             System.out.println();
          }
      } catch (IOException ex) {
        System.out.println(ex);
      } 
      
    }
  
    
    /* Read in lines of text from the keyboard,
     * and print out each line after it is read in.
     * Stop when the user hits control-D.
     */
    public static void displayKeyboardInput () {
      //try {
        Scanner keyboardScan = new Scanner (System.in);
        do
          {
             String line = keyboardScan.nextLine();
             System.out.println (line);
             System.out.println();
          } while (keyboardScan.hasNext());
      //} catch (Exception ex) { //Note: IOException is not thrown by this code. 
       // System.out.println(ex);
      //}
      
    }
    
    /* Read in lines of text from the keyboard,
     * and print out each line after it is read in.
     * Stop when the user enters "quit".
     */
    public static void displayKeyboardInputQ () {
      //try {
        Scanner keyboardScan = new Scanner (System.in);
        String line = keyboardScan.nextLine();
        while (!line.equals("quit"))
          {
             System.out.println (line);
             System.out.println();
             line = keyboardScan.nextLine();
          } 
      //} catch (Exception ex) {
     //   System.out.println(ex);
     // }
      
    }
    
    
    /* Copies an input file to an output file. 
   * Displays an error message if the output file cannot be created. 
   */ 
  public static void copyFile (String inFileName, String outFileName) { 
   try { 
   Scanner reader=new Scanner (new File(inFileName)); 
   PrintWriter writer=new PrintWriter (new File(outFileName)) ;
   
   while (reader.hasNext()) { 
   // Read and write line to output file 
   writer.println(reader.nextLine());} 
   } catch (IOException ex) { 
   System.out.println(ex); // Handle file-not-found 
   } 
  } 
    

    
    // MAIN method
    public static void main (String[] args) {
      if ((args.length == 2) && (args[0].equals("displayFile"))) {
        displayFile(args[1]);
      }
      else if ((args.length == 2) && (args[0].equals("displayWebPage"))) {
        displayWebPage(args[1]);
      }
      else if ((args.length == 1) && (args[0].equals("displayKeyboardInput"))) {
        displayKeyboardInput();
      }
      else if ((args.length == 3) && (args[0].equals("copyFile"))) {
        copyFile(args[1], args[2]);
      } else {
        System.out.println("usage:\n"
                             + "java FileOpsScanner displayFile <inFileName>\n"
                             + "java FileOpsScanner displayWebPage <urlName>\n"
                             + "java FileOpsScanner displayKeyboardInput\n"
                             + "java FileOpsScanner copyFile <inFileName> <outFileName>\n"
                             );
      }
      
    }  // End of "main"
    
  }  // End of FileOpsScanner class
  
