 /**************************************************************************
 *Name: Webpage
 * Authors: Meridian Witt and Meredith McCormack-Mager
 * Date: 9 March 2014
 * Purpose: This is the object that Cyberspace will collect in an array. 
 * In accessing a URL, a Webpage object will be created. 
 **************************************************************************/
import java.util.*;
import java. io.*;
import java.net.URL;

public class Webpage implements Comparable <Webpage>{
  //instance variables
  private String url;
  private int lines;
  
 /**************************************************************************
 *Constructor: This method constructs the object. It will hold the number
 * of lines at the URL and save the name. 
 **************************************************************************/
  
  public Webpage(String url){
   lines = 0;
   this.url = url;  
  }
  
   /**************************************************************************
   ToString: This allows a string representation of the Webpage object. 
 **************************************************************************/
  
  public String toString(){
    return url + "\t:" + lines;
  }
  
/*************************************************************************
  * This method counts the number of lines in the accessed URL. It also has 
  * a try/catch in case no file is found. 
 **************************************************************************/
  
    public void countLinesWeb () {  
    int counter=0;
    try {   
      URL u = new URL (url);
      Scanner urlScan = new Scanner( u.openStream() ); // will throw exception  
      while (urlScan.hasNext())  
      {  
        urlScan.nextLine();  
        counter++;
      }  
    } catch (IOException ex) {  
      System.out.println(ex);  
    }  
    lines = counter;
  }
   
     /**************************************************************************
 *To satisfy the comparable interface, we define a compareTo method, so Cyberspace can 
 * order the Webpage objects in an array.
 **************************************************************************/
    
    public int compareTo(Webpage page){
      int compare = 0;
      if (this.lines > page.lines) compare = 1;
      if (this.lines < page.lines) compare = -1;
      return compare;
    }   
}