import javax.swing.JOptionPane;

public class Vigenere{ //implements encryptable
 //instance variables
 private String password;
 private String given;
 private String encrypted;
 private String decrypted;
 
 public Vigenere(String password, String given){ //take password and given
  this.password = password;
  this.given = given;
  this.encrypted = "";
  this.decrypted = "";
 }
 
 public String encrypt(){
  //loop to count the number of characters in the password = the number of shifts (given%password)
   int passwordLength = password.length();
   int[] shiftHolder = new int[passwordLength];
   for (int j = 0; j <passwordLength; j++){
     shiftHolder[j] = (int)(password.charAt(j)-'A');
   }
   for (int i = 0; i<given.length();i++) {
    int shiftNumber = i%passwordLength; //number of times we want it to loop, helper method to shift around alphabet?
    int shift = shiftHolder[shiftNumber];
    char temp = changeLetter(given.charAt(i), shift);
    encrypted += temp;
   }
   return encrypted;
 }
 
private char changeLetter(char letter, int shift){
  int temp = (letter + shift - 'A');
  temp = (temp+ 26)%26;
  temp = temp + 'A';
  return (char)(temp);
}

public String decrypt(){
  int passwordLength = password.length();
  int[] shiftHolder = new int[passwordLength];
  for (int j = 0; j <passwordLength; j++){
    shiftHolder[j] = (int)(password.charAt(j)-'A');
  }
  for (int i = 0; i<encrypted.length();i++) {
    int shiftNumber = i%passwordLength; //number of times we want it to loop, helper method to shift around alphabet?
    int shift = -(shiftHolder[shiftNumber]);
    System.out.println("This is the shift: " + shift);
    char temp = changeLetter(encrypted.charAt(i), shift);
    decrypted += temp;
  }
  return decrypted;
}

public static void main(String[] args){
  String given, password; 
  int again;
  given = JOptionPane.showInputDialog("What is the message?");
  password = JOptionPane.showInputDialog("What is the password?");
  Vigenere test = new Vigenere(password, given);
  //test.shift();
  //System.out.println(test.encrypted);
  
  
  //encrypted = test.shift();
  JOptionPane.showMessageDialog(null, test.encrypt());
  again = JOptionPane.showConfirmDialog(null, "Do you want it decrypted?");
  if (again == JOptionPane.YES_OPTION){
    JOptionPane.showMessageDialog(null, test.decrypt());
  }
  
  
  //again = JOptionPane.showConfirmationDialog(null, "Do another?")  
}
}