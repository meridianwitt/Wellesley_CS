/* EditSchoolsPanel.java
 CS230 PSET 4 
 Written by: Jasmine Davis and Meridian Witt
Started date: 2/26/14
 */

import java.awt.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.JComboBox;
import javax.swing.text.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;    // Needed for File and FileNotFoundException classes 
import java.util.*;  // Needed to use Scanner class

public class EditSchoolsPanel extends JPanel {
  private GradSchools gradSchools;
  private JButton editB, findB, show;
  private JComboBox editCombo, findCombo;
  private JPanel p1,p2,p3;
  private JTextPane findPane;
  
  public EditSchoolsPanel (GradSchools grads) {
    gradSchools = grads; //putting GradSchool input in an instance variable so it is accessable in ActionListener
    System.out.println("EditSchoolsPanel is getting: " + gradSchools.getNumSchools());
    
    this.setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
    
    ButtonListener bListener = new ButtonListener();
    p1 = new JPanel(new FlowLayout());
    p1.setBackground(Color.cyan);
    this.add(p1,BorderLayout.WEST);
    p1.setPreferredSize(new Dimension(150,350));
    
    //initilizing Find Button, Find Pane, and Show button
    findB = new JButton ("Find Schools");
    findB.addActionListener(bListener);
    p1.add(findB);
    findPane = new JTextPane();
    findPane.setPreferredSize(new Dimension(300,50));
    findPane.setMargin(new Insets(5,5,5,5));
    findPane.setEditable(false);
    show = new JButton("Show Selection");
    show.addActionListener(bListener);
    
    //EDIT BUTTON NOT FULLY IMPLEMENTED
    //editB = new JButton("Edit Schools");
    //editB.addActionListener(bListener);
    //p1.add(editB);
    // p1.add(deleteB);
    
    //initilizing panel2
    p2 = new JPanel(new FlowLayout());
    this.add(p2,BorderLayout.CENTER);
    p2.setBackground(Color.white);
    //initilizing panel3
    p3 = new JPanel(new FlowLayout());

  } //end of EditSchoolsPanel constructor
  
  
  //allows EditSchoolsPanel to set gradSchools instance variable in this panel
  //when it is called in AddSchoolPanel
  public void setGradSchools(GradSchools schools) {
    gradSchools = schools;
    System.out.println("calling esp setter..." + gradSchools);
  }
  
  private class ButtonListener implements ActionListener {
    
    public void actionPerformed(ActionEvent event) {
      
      //if Find button (findB) is clicked
      if (event.getSource() == findB) {
        System.out.println("Clicked findB");
        String[] comboOpt = new String[gradSchools.getNumSchools()+1];
        System.out.println(comboOpt.length);
        comboOpt[0] = "Click Here to Find School";
        System.out.println("testing...." + comboOpt[0]);
        
        for (int i = 1; i <= gradSchools.getNumSchools(); i++) {
          comboOpt[i] = gradSchools.schools[i-1].getName();
          System.out.println("testing..." + comboOpt[i]);
        }
        
        findCombo = new JComboBox(comboOpt);
        p2.add(findCombo);
        System.out.println("findCombo is " + findCombo.isVisible());
        p2.add(show);
        p2.add(p3);
        p3.add(findPane);
        
      } //end of findB if() statement
      
      //if Show button (show) is clicked
      if (event.getSource() == show) {
        System.out.println("Show button has been clicked!");
        int index = findCombo.getSelectedIndex() -1;
        System.out.println("Index found: " + index);
        //p2.add(findPane);
        findPane.setText(gradSchools.schools[index].toString());
        System.out.println(gradSchools.schools[index].toString());
      } //end of show if() statement
      
      //If Edit button (editB) is clicked
      //EDIT BUTTON IS NOT FULLY IMPLEMENTED
      if (event.getSource() == editB) {
        System.out.println("Clicked editB");
        String[] comboOpt = new String[gradSchools.getNumSchools()+1];
        System.out.println(comboOpt.length);
        comboOpt[0] = "Select School To Edit";
        System.out.println("testing...." + comboOpt[0]);
        
        for (int i = 1; i <= gradSchools.getNumSchools(); i++) {
          comboOpt[i] = gradSchools.schools[i-1].getName();
          System.out.println("testing..." + comboOpt[i]);
        }
        
        editCombo = new JComboBox(comboOpt);
        p2.add(editCombo);
        System.out.println("editCombo is " + editCombo.isVisible());
      } //end of editB if() statement
      
    } //end of actionPerfmored of ButtonListener
    
  } //end of ButtonListener
  
  
}//end of EditSchoolsPanel class