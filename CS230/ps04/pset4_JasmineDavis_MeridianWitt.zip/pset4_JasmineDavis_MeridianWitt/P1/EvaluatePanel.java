/* EvaluatePanel.java
 CS230 PSET 4 
 Written by: Jasmine Davis and Meridian Witt
Started date: 2/26/14
 */

import java.awt.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.util.*;

public class EvaluatePanel extends JPanel {
  //instance variables
  private GradSchools gradSchools;
  private JSlider aWeight, rWeight, pWeight, rankSlide;
  private JLabel aLabel, rLabel, pLabel, rank;
  private JTextPane topSchools;
  
  public EvaluatePanel (GradSchools grads) {
    gradSchools = grads;
    SliderListener listener = new SliderListener();
    System.out.println("SCHOOLS has " + gradSchools.getNumSchools()); //coding to test bugs
    this.setBackground(Color.cyan);
    
    //academic weight slider and label
    aWeight = new JSlider(JSlider.HORIZONTAL, 0,5,0);  
    aWeight.setMajorTickSpacing(1);
    aWeight.setPaintTicks(true);
    aWeight.setPaintLabels(true);
    aWeight.setSnapToTicks(true); //prevents users from putting 3.3 and will instead snap to closest tick
    aWeight.setAlignmentX(Component.LEFT_ALIGNMENT);
    //research weight slider and label
    rWeight = new JSlider(JSlider.HORIZONTAL, 0,5,0);
    rWeight.setMajorTickSpacing(1);
    rWeight.setPaintTicks(true);
    rWeight.setPaintLabels(true);
    rWeight.setSnapToTicks(true);
    rWeight.setAlignmentX(Component.CENTER_ALIGNMENT);
    //publications weight slider and label
    pWeight = new JSlider(JSlider.HORIZONTAL, 0,5,0);
    pWeight.setMajorTickSpacing(1);
    pWeight.setPaintTicks(true);
    pWeight.setPaintLabels(true);
    pWeight.setSnapToTicks(true);
    pWeight.setAlignmentX(Component.RIGHT_ALIGNMENT);
    
    aLabel = new JLabel("Academics: 0");
    rLabel = new JLabel("Research: 0");
    pLabel = new JLabel("Publications: 0");
    
    aWeight.addChangeListener(listener);
    rWeight.addChangeListener(listener);
    pWeight.addChangeListener(listener);
    
    add(aLabel);
    add(aWeight);
    add(rLabel);
    add(rWeight);
    add(pLabel);
    add(pWeight);
    
    
    rank = new JLabel("Rank According To:");
    //creating a slide for if user wants to rank by something other than overall
    rankSlide = new JSlider(JSlider.HORIZONTAL, 1, 4, 1);
    rankSlide.addChangeListener(listener);
    rankSlide.setMajorTickSpacing(1);
    rankSlide.setPaintTicks(true);
    rankSlide.setSnapToTicks(true);
    //Creating the label table
    Hashtable labelTable = new Hashtable();
    labelTable.put( 1, new JLabel("Overall") );
    labelTable.put( 2 , new JLabel("Academics") );
    labelTable.put( 3 , new JLabel("Research") );
    labelTable.put( 4 , new JLabel("Publications") );
    rankSlide.setLabelTable( labelTable );
    rankSlide.setPaintLabels(true);
    rankSlide.setPreferredSize(new Dimension(350,40));
    add(rank);
    add(rankSlide);
    
    //creating text pane to display top three schools in rankings
    topSchools = new JTextPane();
    topSchools.setEditable(false);
    topSchools.setText("Please move the sliders to the desired weights in each category. Then pick which category you want to rank by.");
    topSchools.setMargin(new Insets(5,5,5,5));
    topSchools.setPreferredSize(new Dimension(800,300));
    topSchools.setAlignmentX(CENTER_ALIGNMENT);
    add(topSchools);
    
    this.add(Box.createRigidArea(new Dimension (0,5)));
  }
  
  //allows EditSchoolsPanel to set gradSchools instance variable in this panel
  //when it is called in AddSchoolPanel
  public void setGradSchools(GradSchools schools) {
    System.out.println("Calling setter method..." + schools);
    gradSchools = schools;
  }
  
  private class SliderListener implements ChangeListener{
    private int a, r, p;
    
    public void stateChanged (ChangeEvent event) {
      a = aWeight.getValue();
      r = rWeight.getValue();
      p = pWeight.getValue();
      
      aLabel.setText("Academics: " + a);
      rLabel.setText("Research: " + r);
      pLabel.setText("Publications: " + p);
      
      System.out.println("Is gradSchools empty? " + gradSchools.isEmpty());
      //if there is nothing in GradSchools then tell user that collection is empty and you should add schools before evaluating
      if (gradSchools.isEmpty()) {
        topSchools.setText("\t\tThere are no schools in the collection. You should add schools before evaluating.");
      } else if (gradSchools.getNumSchools() == 1){
        topSchools.setText("\t\t There is only one school in the collection. Please add another to compare.\n" + gradSchools);
      } else {
        //need to get topThree and make a table out of after rank value is changed to index numbers 
        gradSchools.computeRatings(a,r,p);
        System.out.println(gradSchools);
        topSchools.setText(gradSchools.toString());
        
        if (rankSlide.getValue() == 1) {
          gradSchools.rankSchools("Overall");
        }
        if (rankSlide.getValue() == 2) {
          gradSchools.rankSchools("Academics");
        }
        if (rankSlide.getValue() == 3) {
          gradSchools.rankSchools("Research");
        }
        if (rankSlide.getValue() == 4) {
          gradSchools.rankSchools("Publications");
        }
        
        topSchools.setText(gradSchools.getTopThree());
        
      } // end of else
    } // end of statechanged()
  }// end of sliderListener
  
}//end of EvaluatePanel