import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GradSchoolsPanel extends JPanel {
}