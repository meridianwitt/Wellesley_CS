/*
 * The FolderOps class supports the following class method:
 *      public static String getFolder();
 * 
 */

import java.io.*;
import java.net.*;
import java.util.*;

public class FolderOps {
  
  
  /**************************************************************
    * public class methods
    * ***********************************************************/
  
  /*
   * Returns a String representing the path
   * to the location of the source/class files. 
   * Returns the empty String if its the current working directory.
   *
   * Why is this here?  DrJava sets the current directory to be the 
   * the location of the DrJava application by default.  On public
   * machines, you can't change this (it will be undone when the
   * machines are reset).  So we include this method to find out
   * where this .class file was loaded from.
   *
   * Problem:  getResource() returns a URL representation of the
   * path.  This means that spaces and other characters will be
   * turned into their URL standard versions (eg, %20 for space).
   * When interpreted as a path name, this will fail.
   */
  public static String getFolder()
  {
    File temp = new File("FolderOps.class");
    if (temp.exists()) {  // Current path gets to source/class files
      return "";
    } else { 
      /* String newPath = "";
       java.net.URL u = FolderOps.class.getResource("/FolderOps.class");
       String path = new File(u.toString()).getParent();
       newPath = path.substring(5, path.length()) + "/";  // Remove "file:"
       */
      String newPath = new File(FolderOps.class.getResource("FolderOps.class").getFile()).getParent() + File.pathSeparator;
      temp = new File(newPath + "FolderOps.class");
      if (temp.exists()) {      // Machinations worked!
        return newPath; 
      } else {                  // Machinations did not work. Try again. 
        newPath = FolderOps.class.getResource("FolderOps.class").toString();
        int firstIndex = newPath.indexOf(":");  /* end of "file:" */
        newPath = newPath.substring(firstIndex + 1);
        
        // For Macs, path (and FolderOps.class) should be accurate here
        // For PCs, path (and FolderOps.class) begins with '/C:' and
        // we want to remove leading slash and change all forward
        // slashes to backward slashes (i.e., File.separator)
        if (newPath.indexOf(":") != -1) {  
          newPath = newPath.substring(1);
        }
        // Replace URL space notation with " "
        newPath = newPath.replaceAll("%20", " "); 
        
        newPath = newPath.replace('/', File.separatorChar);  // Does nothing on Macs
        int lastIndex = newPath.lastIndexOf(File.separatorChar);
        newPath = newPath.substring(0, lastIndex + 1);
        
        temp = new File(newPath + "FolderOps.class");
        if (temp.exists()) {      // Machinations worked!
          return newPath;
        } else {  // Machinations did not work. Give up.
          // Ideally, should allow user to choose file
          String dir1 = new File(".").getAbsolutePath();
          String dir2 = newPath;
          System.err.println("Error: unable to locate ");
          System.err.println("file in:\t\t" + dir1);
          System.err.println("\t\tor\t\t" + dir2);
          throw new RuntimeException();
        }
      }
    }
  }
  
}
