/* AddSchoolPanel.java
 CS230 PSET 4 
 Written by: Jasmine Davis and Meridian Witt
Started date: 2/26/14
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;    // Needed for File and FileNotFoundException classes 
import java.util.*;  // Needed to use Scanner class

public class AddSchoolPanel extends JPanel {
  //instance variables
  private JLabel school, academics, research, publications, help, fileTextLabel, outputFileLabel; 
  private JTextPane info;
  private JTextField schoolText, fileText, outputFileName;
  private JButton addSchoolButton, showAll, fileInput, outputName;
  private JComboBox academicsCombo, researchCombo, pubCombo;
  private JPanel p1,p1half,p2,p3;
  private JScrollPane jsp;
  private GradSchools gradSchools;
  private EvaluatePanel ep;
  private EditSchoolsPanel esp;

  
  public AddSchoolPanel(GradSchools grads, EvaluatePanel ep, EditSchoolsPanel esp) {
    gradSchools = grads; //putting GradSchool input in an instance variable so it is accessable in ActionListener
    this.ep = ep;
    this.esp = esp;
    SchoolListener listener = new SchoolListener();
    FileListener fileListener = new FileListener();
    
    this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    this.setBackground(Color.yellow);
    //creating and populating panel1 and panel1half
    p1 = new JPanel(new FlowLayout());
    this.add(p1);
    help = new JLabel("<html><center><br>Fill in the information to add a school, then click \"Add School\".<br> Or input a file name containing the list of schools.</center></html>"); //help information
    p1.add(help);
    p1.setBackground(Color.cyan);
    
    p1half = new JPanel(new FlowLayout());
    p1half.setBackground(Color.cyan);
    add(p1half);
    //initilizing import file system
    fileTextLabel = new JLabel("File Name: ");
    fileText = new JTextField(10);
    fileText.addActionListener(fileListener);
    fileInput = new JButton("Add From File");
    fileInput.addActionListener(fileListener);
    p1half.add(fileTextLabel);
    p1half.add(fileText);
    p1half.add(fileInput);
    //initilizing export file system
    outputFileLabel = new JLabel("Name of Export File: ");
    outputFileName = new JTextField(10);
    outputFileName.addActionListener(fileListener);
    outputName = new JButton("Export to File");
    outputName.addActionListener(fileListener);
    p1half.add(outputFileLabel);
    p1half.add(outputFileName);
    p1half.add(outputName);
    
    this.add(Box.createRigidArea(new Dimension (0,10)));
    
    //creating and populating panel 2
    p2 = new JPanel(new FlowLayout());
    this.add(p2,BorderLayout.CENTER);
    p2.setBackground(Color.green);
    //school button and input
    school = new JLabel("School: ");
    schoolText = new JTextField(5);
    schoolText.addActionListener(listener);
    p2.add(school);
    p2.add(schoolText);
    
    
    String[] comboOpt = {"...","1","2","3","4","5", "6", "7", "8", "9", "10"}; //combo options
   //academic label and combobox
    academics = new JLabel("Academics: ");
    academicsCombo = new JComboBox(comboOpt);
    academicsCombo.addActionListener(listener);
    p2.add(academics);
    p2.add(academicsCombo);
    //research label and combobox
    research = new JLabel("Research: ");
    researchCombo = new JComboBox(comboOpt);
    researchCombo.addActionListener(listener);
    p2.add(research);
    p2.add(researchCombo);
    //publications label and combobox
    publications = new JLabel("Publications: ");
    pubCombo = new JComboBox(comboOpt );
    pubCombo.addActionListener(listener);
    p2.add(publications);
    p2.add(pubCombo);
    //add school and show all school buttons
    addSchoolButton = new JButton("Add School");
    addSchoolButton.addActionListener(listener);
    showAll = new JButton("Show All Schools");
    showAll.addActionListener(listener);
    p2.add(addSchoolButton);
    p2.add(showAll);
    
    this.add(Box.createRigidArea(new Dimension (0,10)));
    
    //panel 3 is created and populated
    p3 = new JPanel(new FlowLayout());
    this.add(p3);
    p3.setBackground(Color.white);
    info = new JTextPane();
    info.setEditable(false);
    info.setText( "Information on the added schools will appear here.");
    jsp = new JScrollPane(info); //scroll bar created to help display schools if necessary
    jsp.setPreferredSize(new Dimension(800,100));
    p3.add(jsp);
    
    this.add(Box.createRigidArea(new Dimension (0,10)));
  }
  
  
  private class SchoolListener implements ActionListener {
    
    public void actionPerformed(ActionEvent event) {
      String S = ""; //holder for school information
      String school = schoolText.getText();
      int aRank = academicsCombo.getSelectedIndex();
      int acadRank = (aRank == 0)? 1 : aRank;
      int rRank = researchCombo.getSelectedIndex();
      int resRank = (rRank == 0)? 1 : rRank;
      int pRank = pubCombo.getSelectedIndex();
      int pubRank = (pRank == 0)? 1 : pRank;
      S = S + "SCHOOL: " + school;
      S = S + "\t Academics: " + acadRank;
      S = S + "\t Research: " + resRank;
      S = S + "\t Publications: " + pubRank;
      
      //if addSchoolButton is clicked
      if (event.getSource() == addSchoolButton) {
        gradSchools.addSchool(school,acadRank,resRank,pubRank);
        info.setText(S);
        //System.out.println(gradSchools); bug testing code
      }
      //if showAll button is clicked
      if (event.getSource() == showAll) {
        info.setText(gradSchools.toString()); 
      }
      
      ep.setGradSchools(gradSchools); //putting GradSchool input in an instance variable so it is accessable in EvaluatePanel
      esp.setGradSchools(gradSchools); //putting GradSchool input in an instance variable so it is accessable in EditSchoolsPanel
      
    } //end of ActionPerformed()
  } //end of SchoolListener
  
  private class FileListener implements ActionListener {
    
    public void actionPerformed(ActionEvent event) {
      if(!outputFileName.getText().isEmpty()) { //if outputFileName has text (a file name) -- export system
        String exportFileName = outputFileName.getText();
        System.out.println("Exporting to this file name: " + exportFileName);
        try
        {
          System.out.println("Exporting...");
          gradSchools.outputTextFile(exportFileName,gradSchools);
          System.out.println("Export Complete!");
        } catch (FileNotFoundException e) {
          System.out.println("Error while trying to export file.");
          info.setText("Error while trying to export file. Please try again.");
        }
      }
      
      if (!fileText.getText().isEmpty()) { //if fileText.getText() has text (a file name) -- import file system
        String fileName = fileText.getText(); //saves name of file
        System.out.println(fileName);
        try
        {  
          System.out.println("Made it into the Try statement!"); 
          gradSchools = new GradSchools(fileName); //creates a new GradSchools of fileName
          System.out.println("Made it to printing gradSchools after taking input!: \n" + gradSchools);
          info.setText(gradSchools.toString());
        } catch (FileNotFoundException e) {
          System.out.println("File not found.");
          info.setText("File not found. Please try another.");
        } 
      }
      
      ep.setGradSchools(gradSchools); //putting GradSchool input in an instance variable so it is accessable in EvaluatePanel
      esp.setGradSchools(gradSchools); //putting GradSchool input in an instance variable so it is accessable in EditSchoolsPanel
    } //end of ActionPerformed()
  } //end of FiledListener
  
  
} //end of AddSchoolPanel

