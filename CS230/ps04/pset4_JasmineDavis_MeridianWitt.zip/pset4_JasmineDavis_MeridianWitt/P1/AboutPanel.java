/* AboutPanel.java
 CS230 PSET 4 
 Written by: Jasmine Davis and Meridian Witt
Started date: 2/26/14
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AboutPanel extends JPanel {
  private JLabel l1;
  
  public AboutPanel() {
    this.setBackground(Color.cyan);
    
    l1 = new JLabel ("<html><center>Welcome to the GradSchool Choice Application<br>" +
                     "Created by Jasmine Davis and Meridian Witt.<br>" +
                     "------<br>" +
                     "Instructions:<br> Select the 'Add School' tab to add schools, manually or import from a file." 
                       + " You can also export your school list into a file from this tab." + 
                     "<br> Then select the Evaluate tab to evaluate them with weights according to your preference.<br>" + 
                     "If you want to find a school in your list just click the 'Edit Schools' tab." + 
                     "<br> Future updates of this program will finish implementing the 'Edit' button. </center></html>");
    add(l1);
  } 
}