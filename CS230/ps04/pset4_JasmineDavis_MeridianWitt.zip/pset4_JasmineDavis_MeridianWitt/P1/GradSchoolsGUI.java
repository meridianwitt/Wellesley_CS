/* GradSchoolsGUI.java
 CS230 PSET 4 
 Written by: Jasmine Davis and Meridian Witt
Started date: 2/26/14
 */

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;    // Needed for File and FileNotFoundException classes
import java.util.*;  // Needed to use Scanner class
import javax.swing.*;
import javax.swing.text.*;

public class GradSchoolsGUI {
  
  public static void main (String[] args) {
    // creates and shows a Frame 
    JFrame frame = new JFrame("Grad Schools");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setBackground(Color.cyan);
    
    //create an instance of GradSchool
    GradSchools gradSchools = new GradSchools(); 
    
    //create a panel, and add it to the frame
    JTabbedPane tp = new JTabbedPane();
    EditSchoolsPanel esp = new EditSchoolsPanel(gradSchools);
    EvaluatePanel ep = new EvaluatePanel(gradSchools);
    AddSchoolPanel asp = new AddSchoolPanel(gradSchools, ep, esp);
    
    tp.addTab("About", new AboutPanel());
    tp.addTab("Add School", asp);
    tp.addTab("Edit School", esp);
    tp.addTab("Evaluate Schools", ep);
    
    frame.getContentPane().add(tp); //adds in all the tabs
    
    frame.setPreferredSize(new Dimension(910,400));
    
    frame.pack();
    frame.setVisible(true);
  }
  
}