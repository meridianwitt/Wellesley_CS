/*
 *What is a vector? 
 */