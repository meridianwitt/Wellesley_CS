package javafoundations;
import javafoundations.exceptions.*;

public class MatchChecker<T> implements Stack<T>{
  
 
  public MatchChecker(){
  
  }
}