public class VectorStack<T> implements Stack<T>{
 
  public Vector
  
  public boolean isEmpty() {
    return count == 0;
  }
  
  public T pop () throws EmptyCollectionException { 
    if (this.isEmpty()){
      throw new EmptyCollectionException("Pop failed. Stack is empty.");
    } else{
      count--;
      return stack[count];
    }
  }
  
  public T peek () throws EmptyCollectionException {
    if (this.isEmpty()){
      throw new EmptyCollectionException("Peek failed. Stack is empty.");
    }else{
      return stack[count-1];
    }
  }
  
  public int size() {
    return count;
  }
  
  public static void main(String [] args){
    ArrayStack<String> test = new ArrayStack<String>();
    test.push("5");
    System.out.println(test);
    
  }
  
}