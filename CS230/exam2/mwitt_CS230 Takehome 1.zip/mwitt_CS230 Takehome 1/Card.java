/*********************************************
  FileName: Card.java
  Who: Meridian Witt
  When: April 2014
  What: Creates the card object to populate the Deck
*********************************************/

public class Card implements Comparable<Card>{
  //instance variables
  private String value;
  private String suit;
  private int suitOrder; //to compare
  private int order;
  
  /*******************************************
  First Constructor: Takes in a string value and suit
  *******************************************/
  
  public Card(String value, String suit){
   this.value = value; //how to control if the user puts in an erroneous value? make exceptions?
   this.suit = suit.toLowerCase(); //how to control if the user puts in an erroneous suit?
  }
  
  /*******************************************
  Helper method to order the suits in the compareTo, essentially converting string to int to be mathematically compared
  *******************************************/
  
  public int suitOrder (String suit){
    switch(suit){
      case "spades": return 1;
      case "clubs": return 2;
      case "diamonds": return 3;
      case "hearts": return 4;
      default: return 0;
    }
  }
  
  /*******************************************
  Helper method to order the values when card is created by its order in the deck, essentially converting string to int
  *******************************************/
  
  public String valueOrder (int order){
    switch(order){
      case 0: value = "king"; break; //cheating?
      case 1: value = "ace"; break;
      case 11: value = "jack"; break;
      case 12: value = "queen"; break;
      case 13: value = "king"; break;
      default: value = Integer.toString(order); break;
    }
    return value;
  }
  
  /*******************************************
  Helper method to order the values when comparing cards with compareTo(), essentially converting string to ints that can be mathematically compared
  ******************************************/
  
    private int valueCompareTo (String value){
    switch(value){
      case "ace": return 1; 
      case "2": return Integer.parseInt(value);
      case "3": return Integer.parseInt(value);
      case "4": return Integer.parseInt(value);
      case "5": return Integer.parseInt(value);
      case "6": return Integer.parseInt(value);
      case "7": return Integer.parseInt(value);
      case "8": return Integer.parseInt(value);
      case "9": return Integer.parseInt(value);
      case "10": return Integer.parseInt(value);
      case "jack": return 11;
      case "queen": return 12;
      case "king": return 13;
      default: return 0;
    }
  }
    
    public String getSuit(Card c){
     return this.suit;
    }
    
    public String getValue(Card c){
     return this.value;
    }
  
  /*******************************************
  Second Constructor: Creates card only by its order in the deck
  *******************************************/
  
  public Card(int order){
    if(order <= 13) {
      this.suit = "spades";
      this.value = valueOrder(order);
    } else if (order <= 26){
      this.suit = "clubs";
      this.value = valueOrder(order%13);
    } else if (order <= 39){
      this.suit = "diamonds";
      this.value = valueOrder(order%13);
    } else {suit = "hearts"; this.value = valueOrder(order%13);};
  }
  
  /*******************************************
  CompareTo: This method satisfies Comparable interface requirements and allows cards to be compared.
  *******************************************/
  
  public int compareTo(Card another){ // -1 is higher, closer to the front
   int compare = 0;
  
   if(suitOrder(this.suit) < suitOrder(another.suit)) {compare = -1; return compare;} 
   if(suitOrder(this.suit) > suitOrder(another.suit)) {compare = 1; return compare;}
   if(suitOrder(this.suit) == suitOrder(another.suit)){
     if (this.valueCompareTo(this.value) < another.valueCompareTo(another.value)) {compare = -1; return compare;}
     if (this.valueCompareTo(this.value) > another.valueCompareTo(another.value)) { compare = 1; return compare;}}
   return compare;  
  }
  
  /*******************************************
  ToString: Provides String representation of cards
  *******************************************/
  
  public String toString(){
   String s = "";
   s+= "This card is " + ((value == "ace") ? "an " : "a ") + value + " of " + suit + "."; 
   return s;
  }
  
  /*******************************************
  Main: Tests cards and methods created.
  *******************************************/
  
  public static void main(String[] args){
   Card test1 = new Card("ace", "hearts");
   Card test2 = new Card("2", "hearts");
   Card test3 = new Card(1); //should be ace of spades
   //Card test4 = new Card(2);
   //Card test5 = new Card(11);
   //Card test6 = new Card(13);
   //Card test7 = new Card(14);
   //Card test8 = new Card(25);
   //Card test9 = new Card(52); //the ones that make mod 0 are always the last, and always kings, can be put it
   System.out.println(test1);
   //System.out.println(test2);
   System.out.println(test3);
   //System.out.println(test1.compareTo(test2));
   System.out.println(test1.compareTo(test3)); //thinks ace of spades is equivalent to ace of hearts
   //suits: 4>1, values 1=1
   //System.out.println(test1.compareTo(test4));
   //System.out.println(test9.compareTo(test1));
   
  }
}