/*********************************************
  FileName: Deck.java
  Who: Meridian Witt
  When: April 2014
  What: Creates Deck as a collection of cards
*********************************************/

import java.util.LinkedList;

public class Deck{
  //instance variables
  private LinkedList<Card> collection;
  private LinkedList<Card> one;
  private LinkedList<Card> two;
  private LinkedList<Card> interlaced;
  private final int n = 52; //num cards
  private int counter = 0;
  
  private LinkedList where = new LinkedList(); //array to hold target indices
  
  /*********************************************
  Constructor: Creates a LinkedList to hold 52 cards and populates it
  *********************************************/
  public Deck(){
    this.collection = new LinkedList<Card>();
    addCards(collection);
  }
  
  public LinkedList getCollection(){
   return collection;
  }
  
  public String getWhere(){
    String s="";
    for(int i=0; i<where.size()-1;i++){
     s += where.get(i);
    }
    return s;
  }
  
  /*********************************************
  addCards: helper methods populated the linked list with cards
  *********************************************/
  private void addCards(LinkedList<Card> collection){ //where is the king of clubs?
    for(int j=0; j<4; j++){
      String[] suits = {"spades", "clubs", "diamonds", "hearts"};
      for(int i = 0; i<13; i++){
        String[] values = {"ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king"};
        collection.add(new Card(values[i], suits[j]));
      }
    }
  }
  
  /*********************************************
  toString: Allows string representations of Deck
  *********************************************/
  public String toString(){
   String s = "";
   for(int i = 0; i < collection.size(); i++){
   s += collection.get(i);
   }
   return s;
  }
  
  /*********************************************
  subList: The first helper method in perfectShuffle used to divide the deck in half
  *********************************************/
  private void subList(LinkedList<Card> sort){
    this.one = new LinkedList<Card>();
    this.two = new LinkedList<Card>();
    for (int i=0; i<n/2; i++){
      this.one.add(sort.get(i));
    }
    for (int i=n/2; i<n; i++){
      two.add(sort.get(i));
    }
  }
  
  /*********************************************
  interlace: The second helper method in perfectShuffle used to shuffle the deck by interlacing the two haves from sublist
  *********************************************/
  private LinkedList interlace(){
    //interlace
    interlaced = new LinkedList<Card>();
    for (int i=0; i<(n/2); i++){
     interlaced.add(one.get(i));
     interlaced.add(two.get(i));
    }
    return interlaced;
  }
  
  /*********************************************
  perfectShuffle: shuffles the deck until in order again
  
  UNABLE TO IMPLEMENT RECURSIVE STRATEGY
  *********************************************/
  public int perfectShuffle(){ 
 
    for(int i = 0; i<8; i++){ 
    //System.out.println(inOrder(collection));
    subList(collection);
    collection = interlace();
    counter++;
    
   //what I wanted: recursively perfectshuffle interlace the halves, do it until all in order (using boolean inOrder)
   //{subList(interlaced); interlace(); counter++;}while(inOrder(interlaced) == false) 
    }
     return counter;
  }
  
  /*********************************************
  perfectShuffle: shuffles the deck until in order again, overloaded version to find a particular card in shuffling
  
  UNABLE TO IMPLEMENT RECURSIVE STRATEGY
  *********************************************/
  
  public int perfectShuffle(Card search){ 
    for(int i = 0; i<8; i++){ 
      where.add(findinDeck(search));
      System.out.println(findinDeck(search));
      subList(collection);
      collection = interlace();
      counter++;
      
      //what I wanted: recursively perfectshuffle interlace the halves, do it until all in order (using boolean inOrder)
      //{subList(interlaced); interlace(); counter++;}while(inOrder(interlaced) == false) 
    }
    System.out.println(findinDeck(search)); return counter;
  }
  
  /*********************************************
  inOrder: helper method to see if a collection is in order, ideally to be the conditional to stop the perfectShuffle.
  
  CURRENTLY NOT WORKING
  *********************************************/
  private boolean inOrder(LinkedList<Card> order){ 
    //if first two are in order, keep comparing the rest, recursion (two smaller?)
    boolean b=false;
    while(!order.isEmpty() && (b == false)){
      if(order.get(0).compareTo(order.get(1)) == -1){
        order.pop();
        order.pop();
        b = true;} else {b=false;}                                           
    }
    return b;
  }
  
  /*********************************************
  findinDeck: method to find a card and return the index in order to track it through each iteration of shuffling
  
  *********************************************/
  public int findinDeck(Card target){ //to keep track of a card make with just order, right?
   //find the card in the stack
//   String suit = search.getSuit();
//   String value = search.getValue();
//   System.out.println("The location of the card is at index ");
//   return collection.indexOf(search);
//  }
   Card result = null;
   int index = 0;
   while(result==null && index<collection.size()){
     if(collection.get(index).compareTo(target)==0)
       result = collection.get(index);
       index++;
   } System.out.print("The location is at index: "); return index;
   }
  
  /*********************************************
  Main: method to test deck and the other methods
  *********************************************/
  
  public static void main(String[] args){
   Deck myDeck = new Deck();
//   Card card = new Card("6", "hearts");
//   myDeck.collection.add(card);
   //System.out.println(myDeck.collection);
   //System.out.println(myDeck.inOrder(myDeck.collection));
   //System.out.println(myDeck.findinDeck(card));
   //System.out.println(myDeck.collection);
   myDeck.getWhere();
  }
    
}