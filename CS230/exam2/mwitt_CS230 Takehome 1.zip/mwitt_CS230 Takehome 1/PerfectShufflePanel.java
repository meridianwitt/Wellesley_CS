import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PerfectShufflePanel extends JPanel{
 //instance variables
 private JLabel promptLabel, resultLabel; //is that right?
 private JComboBox valueCombo, suitCombo;
 private JButton shuffleButton;
 private String[] valueOptions = {"Value", "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "king", "queen"};
 private String[] suitOptions = {"Suit", "spades", "clubs", "diamonds", "hearts"};
 private Deck myDeck;
 
 private Card made;
 private int shuffle;
 
 public PerfectShufflePanel(Deck myDeck){
   
   this.myDeck = myDeck;
   setPreferredSize(new Dimension(680,100));
   promptLabel = new JLabel("How many perfect shuffles does it take to restore a deck of cards? Click Shuffle!" +
                                "Or, first select suit and value to track.");
   valueCombo = new JComboBox(valueOptions);
   valueCombo.addActionListener(new ComboListener());
   suitCombo = new JComboBox(suitOptions);
   suitCombo.addActionListener(new ComboListener());
   shuffleButton = new JButton("Shuffle!");
   shuffleButton.addActionListener(new ButtonListener());
   add(promptLabel);
   add(valueCombo);
   add(suitCombo);
   add(shuffleButton);
   resultLabel = new JLabel("");
   add(resultLabel);
    }
  
  private class ComboListener implements ActionListener{
     public void actionPerformed(ActionEvent event){
       // get the values of the dropdowns getSelectedIndex, save in a variable suitchoice, valuechoice
       String value = valueOptions[valueCombo.getSelectedIndex()];
       String suit = suitOptions[suitCombo.getSelectedIndex()];
       made = new Card(value, suit);
       //this is the card we have to find in the deck
     }
   }
   
  private class ButtonListener implements ActionListener{
    public void actionPerformed(ActionEvent event){
      if(event.getSource() == shuffleButton){
        // get suit choice and value choice from variable, trace card and record locations through shuffling
        //else () if pull downs are empty, report num perfectshuffles needed
        if(valueCombo.getSelectedIndex() !=0 && suitCombo.getSelectedIndex() != 0){
          String s="Tracing location of card: " + myDeck.getWhere(); //cannot get tracings to print
          s += "It took " +  myDeck.perfectShuffle(made) + " shuffles to restore order.";
          resultLabel.setText(s);
          
        } else {
          String s = "It took " + myDeck.perfectShuffle() + " shuffles to restore order.";
          resultLabel.setText(s);
          
        }
      }
    }
  }
     
   }