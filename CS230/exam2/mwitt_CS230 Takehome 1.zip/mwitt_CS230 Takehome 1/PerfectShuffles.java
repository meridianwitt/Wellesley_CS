public class PerfectShuffles{
 //just the driving method
  
  public static void main(String[] args){
    Deck myDeck = new Deck();
    if(args.length == 2){
     System.out.println(myDeck.perfectShuffle(new Card(args[0], args[1])));
     //System.out.println(myDeck.getCollection());
    } else if (args.length == 0) {
     System.out.println(myDeck.perfectShuffle());
    } else {System.out.println("Run the program without arguments to shuffle or enter 2 arguments to create a card (value and suit)" 
                                 +" and trace through shuffling.");}
  }
}