import javax.swing.*;

public class PerfectShufflesGUI{
  public static void main(String args[]){
   JFrame frame = new JFrame("Perfect Shuffle");
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  
   Deck myDeck = new Deck();
   
   PerfectShufflePanel panel = new PerfectShufflePanel(myDeck);
   
   frame.getContentPane().add(panel);
   frame.pack();
   frame.setVisible(true);
  }
}