public class NotSuitException extends  Exception{
  NotSuitException(String message){
   super(message);
  }
}