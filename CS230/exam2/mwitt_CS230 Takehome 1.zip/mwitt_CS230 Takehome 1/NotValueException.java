public class NotValueException extends  Exception{
  NotValueException(String message){
   super(message);
  }
}